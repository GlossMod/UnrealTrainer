#ifndef UE4SS_SDK_BP_Knowledge_RiftGen_HPP
#define UE4SS_SDK_BP_Knowledge_RiftGen_HPP

class UBP_Knowledge_RiftGen_C : public UKnowledgeForRift
{

    FString GetModuleName();
}; // Size: 0x50

#endif
