#ifndef UE4SS_SDK_BP_ItemCreator_Equip_HPP
#define UE4SS_SDK_BP_ItemCreator_Equip_HPP

class UBP_ItemCreator_Equip_C : public UItemCreatorBase
{

    FString GetModuleName();
}; // Size: 0x30

#endif
