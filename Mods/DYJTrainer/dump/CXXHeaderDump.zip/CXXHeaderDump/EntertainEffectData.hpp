#ifndef UE4SS_SDK_EntertainEffectData_HPP
#define UE4SS_SDK_EntertainEffectData_HPP

struct FEntertainEffectData
{
    FInt32Range ValueRange_2_3A47C16642DACD9B982EE6B6B947061B;                        // 0x0000 (size: 0x10)
    int32 SuccessRate_22_0FF8F90849F4448E1BA28096CCD60514;                            // 0x0010 (size: 0x4)
    int32 FavorAdd_8_E46FB67147AA8A8EFCFC328B77EF23B2;                                // 0x0014 (size: 0x4)
    int32 BigWorldBuffID_21_31D08D034111F8DF52176DAED95C4A64;                         // 0x0018 (size: 0x4)
    FSoftObjectPath SuccessIllustration_14_255A4E094737B0BCCED54681D344A350;          // 0x0020 (size: 0x20)
    FSoftObjectPath FailureIllustration_16_9973594F48A0FED471112C9F3BB177F0;          // 0x0040 (size: 0x20)
    FString EntertainName_19_CB768343447A0A4D8186109C1C1D7FC5;                        // 0x0060 (size: 0x10)
    int32 PlayerMoodAdd_26_887C6E064BAF162B9949C4AD370684EB;                          // 0x0070 (size: 0x4)
    int32 MainGuestMoodAdd_31_FCEE1D054D4018F3C6940DB0A774DBC2;                       // 0x0074 (size: 0x4)
    int32 AreaFameValueAdd_30_B3B29F6D43803940E04BD1B6DBB83892;                       // 0x0078 (size: 0x4)

}; // Size: 0x7C

#endif
