#ifndef UE4SS_SDK_BP_LuaInst_HPP
#define UE4SS_SDK_BP_LuaInst_HPP

class UBP_LuaInst_C : public UFNLuaInstance
{
    class UPrimaryDataAsset* SpecCityBuildConfig;                                     // 0x0050 (size: 0x8)
    TEnumAsByte<E_HideReason::Type> EM_Ref_HideReason;                                // 0x0058 (size: 0x1)
    class UBanquetConfig_C* BanquetConfig;                                            // 0x0060 (size: 0x8)
    class UEntertainEffectConfig_C* EntertainEffectConfig;                            // 0x0068 (size: 0x8)
    class UFameMultConfig_C* FameMultConfig;                                          // 0x0070 (size: 0x8)
    TEnumAsByte<BanquetType::Type> EM_Ref_BanQuetTtype;                               // 0x0078 (size: 0x1)
    FCitySpecialBuildStructure Struct_Ref_CitySpec;                                   // 0x0080 (size: 0x78)

    FString GetModuleName();
}; // Size: 0xF8

#endif
