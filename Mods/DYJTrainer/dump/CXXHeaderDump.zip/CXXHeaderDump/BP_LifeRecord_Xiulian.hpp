#ifndef UE4SS_SDK_BP_LifeRecord_Xiulian_HPP
#define UE4SS_SDK_BP_LifeRecord_Xiulian_HPP

class UBP_LifeRecord_Xiulian_C : public ULifeRecordEntityBase
{
    double AddValue;                                                                  // 0x0030 (size: 0x8)
    double MaxValue;                                                                  // 0x0038 (size: 0x8)
    int32 LoopNum;                                                                    // 0x0040 (size: 0x4)
    FString Text;                                                                     // 0x0048 (size: 0x10)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x58

#endif
