#ifndef UE4SS_SDK_BP_Item_DanLu_HPP
#define UE4SS_SDK_BP_Item_DanLu_HPP

class UBP_Item_DanLu_C : public UItemBase
{
    int32 Durability;                                                                 // 0x0048 (size: 0x4)

    FString GetModuleName();
}; // Size: 0x4C

#endif
