#ifndef UE4SS_SDK_BP_NotifyMessage_UseItem_HPP
#define UE4SS_SDK_BP_NotifyMessage_UseItem_HPP

class UBP_NotifyMessage_UseItem_C : public UFNGameNotifyMessage_UseItem
{

    FString GetModuleName();
}; // Size: 0x78

#endif
