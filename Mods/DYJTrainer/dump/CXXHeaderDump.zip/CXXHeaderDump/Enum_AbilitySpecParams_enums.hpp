namespace Enum_AbilitySpecParams {
    enum Type {
        NewEnumerator1 = 0,
        NewEnumerator2 = 1,
        NewEnumerator3 = 2,
        NewEnumerator4 = 3,
        NewEnumerator5 = 4,
        NewEnumerator6 = 5,
        NewEnumerator7 = 6,
        NewEnumerator8 = 7,
        NewEnumerator14 = 8,
        NewEnumerator9 = 9,
        NewEnumerator16 = 10,
        NewEnumerator17 = 11,
        NewEnumerator18 = 12,
        NewEnumerator19 = 13,
        NewEnumerator10 = 14,
        NewEnumerator11 = 15,
        NewEnumerator12 = 16,
        NewEnumerator13 = 17,
        NewEnumerator20 = 18,
        NewEnumerator22 = 19,
        Enum_MAX = 20,
    };
}

