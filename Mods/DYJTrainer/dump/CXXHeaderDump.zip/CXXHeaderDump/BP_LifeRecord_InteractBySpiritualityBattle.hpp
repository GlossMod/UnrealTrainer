#ifndef UE4SS_SDK_BP_LifeRecord_InteractBySpiritualityBattle_HPP
#define UE4SS_SDK_BP_LifeRecord_InteractBySpiritualityBattle_HPP

class UBP_LifeRecord_InteractBySpiritualityBattle_C : public UInteractRecord
{
    bool RejectBattle;                                                                // 0x0038 (size: 0x1)
    bool BattleResult;                                                                // 0x0039 (size: 0x1)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x3A

#endif
