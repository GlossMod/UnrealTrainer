#ifndef UE4SS_SDK_BP_NotifyMessage_KnowledgeNormal_HPP
#define UE4SS_SDK_BP_NotifyMessage_KnowledgeNormal_HPP

class UBP_NotifyMessage_KnowledgeNormal_C : public UFNGameNotifyMessage_Knowledge
{

    FString GetModuleName();
}; // Size: 0x78

#endif
