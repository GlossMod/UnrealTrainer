#ifndef UE4SS_SDK_BP_LifeRecord_FieldBattle_HPP
#define UE4SS_SDK_BP_LifeRecord_FieldBattle_HPP

class UBP_LifeRecord_FieldBattle_C : public UFieldBattleRecord
{

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x38

#endif
