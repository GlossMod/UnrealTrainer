#ifndef UE4SS_SDK_GA_fulu_HPP
#define UE4SS_SDK_GA_fulu_HPP

class UGA_fulu_C : public UFuWenSkillGameplayAbility
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0748 (size: 0x8)

    void K2_ActivateAbility();
    void ExecuteUbergraph_GA_fulu(int32 EntryPoint);
}; // Size: 0x750

#endif
