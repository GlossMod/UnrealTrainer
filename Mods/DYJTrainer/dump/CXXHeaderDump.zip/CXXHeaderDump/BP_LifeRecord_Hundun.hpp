#ifndef UE4SS_SDK_BP_LifeRecord_Hundun_HPP
#define UE4SS_SDK_BP_LifeRecord_Hundun_HPP

class UBP_LifeRecord_Hundun_C : public UExploreHundunRift
{

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x30

#endif
