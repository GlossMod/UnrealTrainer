#ifndef UE4SS_SDK_BP_LifeRecord_InteractBySBlackmail_HPP
#define UE4SS_SDK_BP_LifeRecord_InteractBySBlackmail_HPP

class UBP_LifeRecord_InteractBySBlackmail_C : public UInteractRecord
{
    int32 ItemId;                                                                     // 0x0038 (size: 0x4)
    bool isEscape;                                                                    // 0x003C (size: 0x1)
    bool IsKill;                                                                      // 0x003D (size: 0x1)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x3E

#endif
