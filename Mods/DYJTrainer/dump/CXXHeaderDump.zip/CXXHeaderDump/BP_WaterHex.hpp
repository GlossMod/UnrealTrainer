#ifndef UE4SS_SDK_BP_WaterHex_HPP
#define UE4SS_SDK_BP_WaterHex_HPP

class UBP_WaterHex_C : public UAreaLandTypeDescBase
{
}; // Size: 0x88

#endif
