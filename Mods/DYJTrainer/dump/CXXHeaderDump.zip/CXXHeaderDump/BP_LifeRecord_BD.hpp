#ifndef UE4SS_SDK_BP_LifeRecord_BD_HPP
#define UE4SS_SDK_BP_LifeRecord_BD_HPP

class UBP_LifeRecord_BD_C : public UBDRecord
{

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x38

#endif
