#ifndef UE4SS_SDK_BP_LifeRecord_ReduceAge_HPP
#define UE4SS_SDK_BP_LifeRecord_ReduceAge_HPP

class UBP_LifeRecord_ReduceAge_C : public ULifeRecordEntityBase
{
    int32 ReduceAge;                                                                  // 0x0030 (size: 0x4)
    FString Text;                                                                     // 0x0038 (size: 0x10)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x48

#endif
