#ifndef UE4SS_SDK_BP_Knowledge_RiftNotice_HPP
#define UE4SS_SDK_BP_Knowledge_RiftNotice_HPP

class UBP_Knowledge_RiftNotice_C : public UKnowledgeForRiftNotice
{

    FString GetModuleName();
}; // Size: 0x48

#endif
