#ifndef UE4SS_SDK_BP_ItemUse_Charm_HPP
#define UE4SS_SDK_BP_ItemUse_Charm_HPP

class UBP_ItemUse_Charm_C : public UItemUseFunction
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0030 (size: 0x8)
    FEnttIndex Causer Entity;                                                         // 0x0038 (size: 0x8)
    int32 User ID;                                                                    // 0x0040 (size: 0x4)
    int32 BuffID;                                                                     // 0x0044 (size: 0x4)
    int32 CreateArttributeCheack;                                                     // 0x0048 (size: 0x4)
    int32 CreateArttributeBuff;                                                       // 0x004C (size: 0x4)
    ESpecialProductSubtype Special Product Subtype;                                   // 0x0050 (size: 0x1)
    TArray<FString> Dec List;                                                         // 0x0058 (size: 0x10)
    FName Sound Name;                                                                 // 0x0068 (size: 0x8)

    void PlaySound(int32 UserID, const class UObject* WorldContextObject);
    void OnAction_AF713FB84A0F4A004C24428BE762DF95(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnEnd_AF713FB84A0F4A004C24428BE762DF95(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnStart_AF713FB84A0F4A004C24428BE762DF95(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void ItemSpecialUse(class UItemBase* Item, int32 UserID);
    void ExecuteUbergraph_BP_ItemUse_Charm(int32 EntryPoint);
}; // Size: 0x70

#endif
