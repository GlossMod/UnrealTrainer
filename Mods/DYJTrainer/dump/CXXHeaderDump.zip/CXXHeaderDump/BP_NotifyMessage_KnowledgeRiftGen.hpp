#ifndef UE4SS_SDK_BP_NotifyMessage_KnowledgeRiftGen_HPP
#define UE4SS_SDK_BP_NotifyMessage_KnowledgeRiftGen_HPP

class UBP_NotifyMessage_KnowledgeRiftGen_C : public UFNGameNotifyMessage_KnowledgeRift
{

    FString GetModuleName();
}; // Size: 0x80

#endif
