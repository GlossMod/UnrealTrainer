#ifndef UE4SS_SDK_FameMultConfig_HPP
#define UE4SS_SDK_FameMultConfig_HPP

class UFameMultConfig_C : public UPrimaryDataAsset
{
    TArray<FFameMultData> FameMultArray;                                              // 0x0030 (size: 0x10)

}; // Size: 0x40

#endif
