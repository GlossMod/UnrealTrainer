#ifndef UE4SS_SDK_BP_LifeRecordMechanic_HPP
#define UE4SS_SDK_BP_LifeRecordMechanic_HPP

class UBP_LifeRecordMechanic_C : public URPGLifeRecordMechanic
{
}; // Size: 0xA0

#endif
