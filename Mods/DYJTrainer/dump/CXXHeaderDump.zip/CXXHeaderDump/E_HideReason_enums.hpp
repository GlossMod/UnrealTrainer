namespace E_HideReason {
    enum Type {
        NewEnumerator0 = 0,
        E_MAX = 1,
    };
}

