#ifndef UE4SS_SDK_BP_LifeRecord_ZMJobRaise_HPP
#define UE4SS_SDK_BP_LifeRecord_ZMJobRaise_HPP

class UBP_LifeRecord_ZMJobRaise_C : public UZMJobRaiseRecord
{

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x38

#endif
