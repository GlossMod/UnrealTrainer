#ifndef UE4SS_SDK_BP_FNMontageManger_HPP
#define UE4SS_SDK_BP_FNMontageManger_HPP

class UBP_FNMontageManger_C : public UFNMontageManger
{
}; // Size: 0x180

#endif
