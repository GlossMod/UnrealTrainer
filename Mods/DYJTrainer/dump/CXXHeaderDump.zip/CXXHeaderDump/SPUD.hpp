#ifndef UE4SS_SDK_SPUD_HPP
#define UE4SS_SDK_SPUD_HPP

#include "SPUD_enums.hpp"

class ASpudActorBase : public AActor
{
    FGuid SpudGuid;                                                                   // 0x0298 (size: 0x10)

}; // Size: 0x2A8

class ASpudCharacterBase : public ACharacter
{
    FGuid SpudGuid;                                                                   // 0x0620 (size: 0x10)

}; // Size: 0x630

class ASpudPawnBase : public APawn
{
    FGuid SpudGuid;                                                                   // 0x0320 (size: 0x10)

}; // Size: 0x330

class ASpudStreamingVolume : public AVolume
{
    TArray<FSoftObjectPath> StreamingLevels;                                          // 0x02C8 (size: 0x10)
    TArray<class AActor*> RelevantActorsInVolume;                                     // 0x02D8 (size: 0x10)
    TArray<class APawn*> PawnsInVolume;                                               // 0x02E8 (size: 0x10)

    void OnPawnControllerChanged(class APawn* Pawn, class AController* NewCtrl);
}; // Size: 0x2F8

class ISpudObject : public IInterface
{
}; // Size: 0x28

class ISpudObjectCallback : public IInterface
{

    void SpudStoreCustomData(const class USpudState* State, class USpudStateCustomData* CustomData);
    void SpudRestoreCustomData(class USpudState* State, class USpudStateCustomData* CustomData);
    void SpudPreStore(const class USpudState* State);
    void SpudPreRestoreDataModelUpgrade(class USpudState* State, int32 StoredVersion, int32 CurrentVersion);
    void SpudPreRestore(const class USpudState* State);
    void SpudPostStore(const class USpudState* State);
    void SpudPostRestoreDataModelUpgrade(const class USpudState* State, int32 StoredVersion, int32 CurrentVersion);
    void SpudPostRestore(const class USpudState* State);
}; // Size: 0x28

class USpudCustomSaveInfo : public UObject
{

    void SetVector(FString Name, const FVector& V);
    void SetText(FString Name, const FText& S);
    void SetString(FString Name, FString S);
    void SetLinearColor(FString Name, const FLinearColor& L);
    void SetInt64(FString Name, int64 V);
    void SetInt(FString Name, int32 V);
    void SetFloat(FString Name, float V);
    void SetByte(FString Name, uint8 V);
    void Reset();
    bool GetVector(FString Name, FVector& OutVector);
    bool GetText(FString Name, FText& OutText);
    bool GetString(FString Name, FString& OutString);
    bool GetLinearColor(FString Name, FLinearColor& OutLinearColor);
    bool GetInt64(FString Name, int64& OutInt64);
    bool GetInt(FString Name, int32& OutInt);
    bool GetFloat(FString Name, float& OutFloat);
    bool GetByte(FString Name, uint8& OutByte);
}; // Size: 0x88

class USpudSaveGameInfo : public UObject
{
    FText Title;                                                                      // 0x0028 (size: 0x18)
    FDateTime Timestamp;                                                              // 0x0040 (size: 0x8)
    FString SlotName;                                                                 // 0x0048 (size: 0x10)
    class UTexture2D* Thumbnail;                                                      // 0x0058 (size: 0x8)
    class USpudCustomSaveInfo* CustomInfo;                                            // 0x0060 (size: 0x8)

}; // Size: 0x68

class USpudState : public UObject
{
    TArray<class UScriptStruct*> HasCallbackStruct;                                   // 0x0560 (size: 0x10)

    void SetTitle(const FText& Title);
    void SetTimestamp(const FDateTime& Timestamp);
    void SetScreenshot(TArray<uint8>& ImgData);
    void SetCustomSaveInfo(const class USpudCustomSaveInfo* ExtraInfo);
    bool RenameProperty(FString ClassName, FString OldPropertyName, FString NewPropertyName, FString OldPrefix, FString NewPrefix);
    bool RenameLevelObject(FString LevelName, FString OldName, FString NewName);
    bool RenameGlobalObject(FString OldName, FString NewName);
    bool RenameClass(FString OldClassName, FString NewClassName);
    FText GetTitle();
    FDateTime GetTimestamp();
    FString GetSource();
    TArray<FString> GetLevelNames(bool bLoadedOnly);
    void ClearLevel(FString LevelName);
}; // Size: 0x578

class USpudStateCustomData : public UObject
{

    void WriteVector(const FVector& V);
    void WriteTransform(const FTransform& T);
    void WriteText(const FText& S);
    void WriteString(FString S);
    void WriteRotator(const FRotator& Rot);
    void WriteQuaternion(const FQuat& Q);
    void WriteInt64(int64 V);
    void WriteInt(int32 V);
    void WriteFloat(float V);
    void WriteByte(uint8 V);
    bool ReadVector(FVector& OutVector);
    bool ReadTransform(FTransform& OutTransform);
    bool ReadText(FText& OutText);
    bool ReadString(FString& OutString);
    bool ReadRotator(FRotator& OutRotator);
    bool ReadQuaternion(FQuat& OutQuaternion);
    bool ReadInt64(int64& OutInt64);
    bool ReadInt(int32& OutInt);
    bool ReadFloat(float& OutFloat);
    bool ReadByte(uint8& OutByte);
}; // Size: 0x38

class USpudSubsystem : public UGameInstanceSubsystem
{
    FSpudSubsystemPreLoadGame PreLoadGame;                                            // 0x0038 (size: 0x10)
    void SpudPreLoadGame(FString SlotName, class USpudState* SaveState);
    FSpudSubsystemPostLoadGame PostLoadGame;                                          // 0x0048 (size: 0x10)
    void SpudPostLoadGame(FString SlotName, bool bSuccess);
    FSpudSubsystemPreSaveGame PreSaveGame;                                            // 0x0058 (size: 0x10)
    void SpudPreSaveGame(FString SlotName);
    FSpudSubsystemPostSaveGame PostSaveGame;                                          // 0x0068 (size: 0x10)
    void SpudPostSaveGame(FString SlotName, bool bSuccess);
    FSpudSubsystemPreLevelStore PreLevelStore;                                        // 0x0078 (size: 0x10)
    void SpudPreLevelStore(FString LevelName);
    FSpudSubsystemPostLevelStore PostLevelStore;                                      // 0x0088 (size: 0x10)
    void SpudPostLevelStore(FString LevelName, bool bSuccess);
    FSpudSubsystemPreLevelRestore PreLevelRestore;                                    // 0x0098 (size: 0x10)
    void SpudPreLevelRestore(FString LevelName);
    FSpudSubsystemPostLevelRestore PostLevelRestore;                                  // 0x00A8 (size: 0x10)
    void SpudPostLevelRestore(FString LevelName, bool bSuccess);
    FSpudSubsystemPreTravelToNewMap PreTravelToNewMap;                                // 0x00B8 (size: 0x10)
    void SpudPreTravelToNewMap(FString NextMapName);
    FSpudSubsystemPostTravelToNewMap PostTravelToNewMap;                              // 0x00C8 (size: 0x10)
    void SpudPostTravelToNewMap();
    FSpudSubsystemPreLoadStreamingLevel PreLoadStreamingLevel;                        // 0x00D8 (size: 0x10)
    void SpudPreLoadStreamingLevel(const FName& LevelName);
    FSpudSubsystemPostLoadStreamingLevel PostLoadStreamingLevel;                      // 0x00E8 (size: 0x10)
    void SpudPostLoadStreamingLevel(const FName& LevelName);
    FSpudSubsystemPreUnloadStreamingLevel PreUnloadStreamingLevel;                    // 0x00F8 (size: 0x10)
    void SpudPreUnloadStreamingLevel(const FName& LevelName);
    FSpudSubsystemPostUnloadStreamingLevel PostUnloadStreamingLevel;                  // 0x0108 (size: 0x10)
    void SpudPostUnloadStreamingLevel(const FName& LevelName);
    float StreamLevelUnloadDelay;                                                     // 0x0118 (size: 0x4)
    int32 ScreenshotWidth;                                                            // 0x011C (size: 0x4)
    int32 ScreenshotHeight;                                                           // 0x0120 (size: 0x4)
    class USpudCustomSaveInfo* ExtraInfoInProgress;                                   // 0x0280 (size: 0x8)
    TArray<TWeakObjectPtr<UObject>> GlobalObjects;                                    // 0x0288 (size: 0x10)
    TMap<class FString, class TWeakObjectPtr<UObject>> NamedGlobalObjects;            // 0x0298 (size: 0x50)
    ESpudSystemState CurrentState;                                                    // 0x02E8 (size: 0x1)
    class USpudState* ActiveState;                                                    // 0x02F0 (size: 0x8)

    void WithdrawRequestForStreamingLevel(class UObject* Requester, FName LevelName);
    void UpgradeAllSaveGames(bool bUpgradeEvenIfNoUserDataModelVersionDifferences, FUpgradeAllSaveGamesSaveNeedsUpgradingCallback SaveNeedsUpgradingCallback, FLatentActionInfo LatentInfo);
    void ScreenshotTimedOut();
    void SaveGame(FString SlotName, const FText& Title, bool bTakeScreenshot, const class USpudCustomSaveInfo* ExtraInfo);
    void RemovePersistentGlobalObject(class UObject* Obj);
    void QuickSaveGame(FText Title, bool bTakeScreenshot, const class USpudCustomSaveInfo* ExtraInfo);
    void QuickLoadGame();
    void PostUnloadStreamLevelGameThread(FName LevelName);
    void PostUnloadStreamLevel(int32 LinkID);
    void PostLoadStreamLevelGameThread(FName LevelName);
    void PostLoadStreamLevel(int32 LinkID);
    void OnSeamlessTravelTransition(class UWorld* World);
    void OnScreenshotCaptured(int32 Width, int32 Height, const TArray<FColor>& Colours);
    void OnPreLoadMap(FString MapName);
    void OnPostLoadMap(class UWorld* World);
    void OnActorDestroyed(class AActor* Actor);
    void NotifyLevelUnloadedExternally(class ULevel* Level);
    void NotifyLevelLoadedExternally(FName LevelName);
    void NewGame(bool CheckServerOnly);
    void LoadLatestSaveGame();
    void LoadGame(FString SlotName);
    bool IsSavingGame();
    bool IsQuickSave(FString SlotName);
    bool IsLoadingGame();
    bool IsIdle();
    bool IsAutoSave(FString SlotName);
    int32 GetUserDataModelVersion();
    TArray<class USpudSaveGameInfo*> GetSaveGameList(bool bIncludeQuickSave, bool bIncludeAutoSave, ESpudSaveSorting Sorting);
    class USpudSaveGameInfo* GetSaveGameInfo(FString SlotName);
    class USpudSaveGameInfo* GetQuickSaveGame();
    class USpudSaveGameInfo* GetLatestSaveGame();
    class USpudSaveGameInfo* GetAutoSaveGame();
    void ForceReset();
    void EndGame();
    bool DeleteSave(FString SlotName);
    class USpudCustomSaveInfo* CreateCustomSaveInfo();
    void ClearLevelState(FString LevelName);
    bool CheckArchiveCanLoad(FString SlotName, int32 MinVersionSupport);
    void AutoSaveGame(FText Title, bool bTakeScreenshot, const class USpudCustomSaveInfo* ExtraInfo);
    void AddRequestForStreamingLevel(class UObject* Requester, FName LevelName, bool BlockingLoad);
    void AddPersistentGlobalObjectWithName(class UObject* Obj, FString Name);
    void AddPersistentGlobalObject(class UObject* Obj);
}; // Size: 0x348

#endif
