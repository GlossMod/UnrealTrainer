#ifndef UE4SS_SDK_BP_LifeRecord_InteractByNormalChat_HPP
#define UE4SS_SDK_BP_LifeRecord_InteractByNormalChat_HPP

class UBP_LifeRecord_InteractByNormalChat_C : public UInteractRecord
{
    bool SucceedChat;                                                                 // 0x0038 (size: 0x1)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x39

#endif
