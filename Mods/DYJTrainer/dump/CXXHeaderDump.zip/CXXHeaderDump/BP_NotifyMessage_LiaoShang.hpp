#ifndef UE4SS_SDK_BP_NotifyMessage_LiaoShang_HPP
#define UE4SS_SDK_BP_NotifyMessage_LiaoShang_HPP

class UBP_NotifyMessage_LiaoShang_C : public UFNGameNotifyMessage_CellRelevance
{

    FString GetModuleName();
}; // Size: 0x78

#endif
