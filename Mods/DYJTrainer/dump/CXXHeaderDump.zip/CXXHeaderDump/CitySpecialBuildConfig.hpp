#ifndef UE4SS_SDK_CitySpecialBuildConfig_HPP
#define UE4SS_SDK_CitySpecialBuildConfig_HPP

class UCitySpecialBuildConfig_C : public UPrimaryDataAsset
{
    TArray<FCitySpecialBuildStructure> CitySpecialBuildConfigs;                       // 0x0030 (size: 0x10)

}; // Size: 0x40

#endif
