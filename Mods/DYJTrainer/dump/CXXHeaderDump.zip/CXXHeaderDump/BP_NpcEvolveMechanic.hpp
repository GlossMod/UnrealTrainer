#ifndef UE4SS_SDK_BP_NpcEvolveMechanic_HPP
#define UE4SS_SDK_BP_NpcEvolveMechanic_HPP

class UBP_NpcEvolveMechanic_C : public UNpcEvolveMechanic
{
}; // Size: 0x148

#endif
