#ifndef UE4SS_SDK_BP_NotifyMessage_LearnJiYi_HPP
#define UE4SS_SDK_BP_NotifyMessage_LearnJiYi_HPP

class UBP_NotifyMessage_LearnJiYi_C : public UBP_NotifyMessage_LearnLingFa_C
{

    FString GetModuleName();
}; // Size: 0x78

#endif
