#ifndef UE4SS_SDK_BP_Knowledge_KillDeath_HPP
#define UE4SS_SDK_BP_Knowledge_KillDeath_HPP

class UBP_Knowledge_KillDeath_C : public UKnowledgeForKillDeath
{

    FString GetModuleName();
}; // Size: 0x50

#endif
