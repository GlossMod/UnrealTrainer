#ifndef UE4SS_SDK_BP_Knowledge_StaticNpc2005_HPP
#define UE4SS_SDK_BP_Knowledge_StaticNpc2005_HPP

class UBP_Knowledge_StaticNpc2005_C : public UKnowledgeBase
{
    int32 PresetID;                                                                   // 0x0048 (size: 0x4)
    FString NpcDec;                                                                   // 0x0050 (size: 0x10)
    bool IsBegin;                                                                     // 0x0060 (size: 0x1)

}; // Size: 0x61

#endif
