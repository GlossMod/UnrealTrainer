#ifndef UE4SS_SDK_FameMultData_HPP
#define UE4SS_SDK_FameMultData_HPP

struct FFameMultData
{
    FInt32Range FameRange_2_852899D6492D4A02A7FA9D8AF8FDD582;                         // 0x0000 (size: 0x10)
    FString Text_5_2451C2894700E7AAD04BF6BC00F85BFC;                                  // 0x0010 (size: 0x10)
    int32 Value_8_E3A42D0645D6D83FBFF040B4E5428BD3;                                   // 0x0020 (size: 0x4)

}; // Size: 0x24

#endif
