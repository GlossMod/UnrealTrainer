#ifndef UE4SS_SDK_BP_LifeRecord_LearnLingfa_HPP
#define UE4SS_SDK_BP_LifeRecord_LearnLingfa_HPP

class UBP_LifeRecord_LearnLingfa_C : public ULearnLingfaRecord
{
    FString Text;                                                                     // 0x0038 (size: 0x10)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x48

#endif
