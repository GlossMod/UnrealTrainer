#ifndef UE4SS_SDK_BP_NotifyMessage_CommonText_HPP
#define UE4SS_SDK_BP_NotifyMessage_CommonText_HPP

class UBP_NotifyMessage_CommonText_C : public UCommonMsgNotify
{
}; // Size: 0x80

#endif
