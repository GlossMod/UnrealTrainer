enum class EProcMeshSliceCapOption {
    NoCap = 0,
    CreateNewSectionForCap = 1,
    UseLastSectionForCap = 2,
    EProcMeshSliceCapOption_MAX = 3,
};

