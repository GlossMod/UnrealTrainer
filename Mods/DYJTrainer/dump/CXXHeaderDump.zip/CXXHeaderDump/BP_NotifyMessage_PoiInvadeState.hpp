#ifndef UE4SS_SDK_BP_NotifyMessage_PoiInvadeState_HPP
#define UE4SS_SDK_BP_NotifyMessage_PoiInvadeState_HPP

class UBP_NotifyMessage_PoiInvadeState_C : public UFNGameNotifyMessage_Invade
{

    FString GetModuleName();
}; // Size: 0x78

#endif
