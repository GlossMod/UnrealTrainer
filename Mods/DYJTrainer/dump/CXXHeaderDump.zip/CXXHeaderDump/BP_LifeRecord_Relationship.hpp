#ifndef UE4SS_SDK_BP_LifeRecord_Relationship_HPP
#define UE4SS_SDK_BP_LifeRecord_Relationship_HPP

class UBP_LifeRecord_Relationship_C : public URelationshipRecord
{

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x40

#endif
