#ifndef UE4SS_SDK_BP_FNGameMsgNotifyCenter_HPP
#define UE4SS_SDK_BP_FNGameMsgNotifyCenter_HPP

class UBP_FNGameMsgNotifyCenter_C : public UFNGameNotifyMessageCenter
{
}; // Size: 0x108

#endif
