#ifndef UE4SS_SDK_BP_ImmSKillNotiy_HPP
#define UE4SS_SDK_BP_ImmSKillNotiy_HPP

class UBP_ImmSKillNotiy_C : public UBattleAbilityAnimNotify
{
    FGameplayTag EventTag;                                                            // 0x0038 (size: 0x8)

    bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference);
}; // Size: 0x40

#endif
