#ifndef UE4SS_SDK_BP_LifeRecord_InteractByAskForItem_HPP
#define UE4SS_SDK_BP_LifeRecord_InteractByAskForItem_HPP

class UBP_LifeRecord_InteractByAskForItem_C : public UInteractRecord
{
    bool SucceedGet;                                                                  // 0x0038 (size: 0x1)
    int32 ItemId;                                                                     // 0x003C (size: 0x4)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x40

#endif
