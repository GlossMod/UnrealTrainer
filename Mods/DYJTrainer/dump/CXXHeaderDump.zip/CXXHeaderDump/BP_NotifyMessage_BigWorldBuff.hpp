#ifndef UE4SS_SDK_BP_NotifyMessage_BigWorldBuff_HPP
#define UE4SS_SDK_BP_NotifyMessage_BigWorldBuff_HPP

class UBP_NotifyMessage_BigWorldBuff_C : public UFNGameNotifyMessage_BigWorldBuff
{

    FString GetModuleName();
}; // Size: 0x78

#endif
