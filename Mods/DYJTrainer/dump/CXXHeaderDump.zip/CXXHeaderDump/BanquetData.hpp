#ifndef UE4SS_SDK_BanquetData_HPP
#define UE4SS_SDK_BanquetData_HPP

struct FBanquetData
{
    TEnumAsByte<BanquetType::Type> Type_23_9D88E0E640FCEEE285A0058ED14693CB;          // 0x0000 (size: 0x1)
    int32 Initialization_4_4A424B054AFA8D88DD61568D0FBFEF77;                          // 0x0004 (size: 0x4)
    int32 MainGuestRelationshipAdd_24_0BF938264754E88A706E4C858467AEF7;               // 0x0008 (size: 0x4)
    int32 SecGuestRelationshipAdd_25_46FED3C848DA80B70ECB678EB227EA55;                // 0x000C (size: 0x4)
    int32 ImpressionAdd_16_B563151B44A28D569E0FB29185A2AF5B;                          // 0x0010 (size: 0x4)
    int32 StageMult_17_18FF49F74FBE729BACAD25A1F4B93C7D;                              // 0x0014 (size: 0x4)
    int32 FameMult_18_7932739140728877482207B0361C55D4;                               // 0x0018 (size: 0x4)
    int32 Price_19_C44EF06B4F58E5CA087F1D86B745A6F9;                                  // 0x001C (size: 0x4)
    int32 Time_21_6D2FB35040C15920924CF0913CAAA413;                                   // 0x0020 (size: 0x4)

}; // Size: 0x24

#endif
