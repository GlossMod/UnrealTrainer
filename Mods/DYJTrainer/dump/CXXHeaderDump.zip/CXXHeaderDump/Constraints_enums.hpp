enum class EHandleEvent {
    LocalTransformUpdated = 0,
    GlobalTransformUpdated = 1,
    ComponentUpdated = 2,
    Max = 3,
};

