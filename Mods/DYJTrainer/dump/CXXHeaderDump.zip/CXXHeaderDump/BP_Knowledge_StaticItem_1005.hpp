#ifndef UE4SS_SDK_BP_Knowledge_StaticItem_1005_HPP
#define UE4SS_SDK_BP_Knowledge_StaticItem_1005_HPP

class UBP_Knowledge_StaticItem_1005_C : public UKnowledgeBase
{
    int32 ItemId;                                                                     // 0x0048 (size: 0x4)
    TArray<FString> ItemAttributeList;                                                // 0x0050 (size: 0x10)
    bool IsInnate;                                                                    // 0x0060 (size: 0x1)
    int32 PresetID;                                                                   // 0x0064 (size: 0x4)

}; // Size: 0x68

#endif
