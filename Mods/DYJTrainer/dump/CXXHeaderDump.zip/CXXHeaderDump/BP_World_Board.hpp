#ifndef UE4SS_SDK_BP_World_Board_HPP
#define UE4SS_SDK_BP_World_Board_HPP

class ABP_World_Board_C : public ABigWorldActorBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x02C8 (size: 0x8)
    class UStaticMeshComponent* SM_Town_7;                                            // 0x02D0 (size: 0x8)
    class UBP_PoiSceneUICpt_C* BP_PoiSceneUICpt;                                      // 0x02D8 (size: 0x8)
    double MoveToTargetTime;                                                          // 0x02E0 (size: 0x8)
    float Back Time;                                                                  // 0x02E8 (size: 0x4)
    float Stop Duration;                                                              // 0x02EC (size: 0x4)

    void StartAction(int32 ActionIndex);
    void CustomEvent(class AActor* SpwaningActor);
    void ExecuteUbergraph_BP_World_Board(int32 EntryPoint);
}; // Size: 0x2F0

#endif
