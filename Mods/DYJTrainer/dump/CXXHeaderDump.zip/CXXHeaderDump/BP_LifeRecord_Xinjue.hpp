#ifndef UE4SS_SDK_BP_LifeRecord_Xinjue_HPP
#define UE4SS_SDK_BP_LifeRecord_Xinjue_HPP

class UBP_LifeRecord_Xinjue_C : public ULifeRecordEntityBase
{

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x30

#endif
