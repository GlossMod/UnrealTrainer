#ifndef UE4SS_SDK_BP_Item_Mount_HPP
#define UE4SS_SDK_BP_Item_Mount_HPP

class UBP_Item_Mount_C : public UItemEquipment
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00E8 (size: 0x8)
    FBigWorldAttributeName InsightAttribute;                                          // 0x00F0 (size: 0x8)

    void EquipItem(int32 UserID, bool bEquipment);
    void ExecuteUbergraph_BP_Item_Mount(int32 EntryPoint);
}; // Size: 0xF8

#endif
