#ifndef UE4SS_SDK_BP_Knowledge_Danfang023_HPP
#define UE4SS_SDK_BP_Knowledge_Danfang023_HPP

class UBP_Knowledge_Danfang023_C : public UKnowledgeBase
{
    int32 ItemId;                                                                     // 0x0048 (size: 0x4)

    FString GetModuleName();
}; // Size: 0x4C

#endif
