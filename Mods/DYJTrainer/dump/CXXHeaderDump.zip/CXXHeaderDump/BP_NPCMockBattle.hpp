#ifndef UE4SS_SDK_BP_NPCMockBattle_HPP
#define UE4SS_SDK_BP_NPCMockBattle_HPP

class UBP_NPCMockBattle_C : public UNPCMockBattle
{

    FString GetModuleName();
}; // Size: 0x50

#endif
