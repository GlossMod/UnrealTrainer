#ifndef UE4SS_SDK_GE_Damage_Basic_ForceToDeath_HPP
#define UE4SS_SDK_GE_Damage_Basic_ForceToDeath_HPP

class UGE_Damage_Basic_ForceToDeath_C : public UGE_Damage_Basic_C
{
}; // Size: 0x868

#endif
