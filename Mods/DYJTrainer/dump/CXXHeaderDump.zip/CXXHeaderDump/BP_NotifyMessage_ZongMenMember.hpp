#ifndef UE4SS_SDK_BP_NotifyMessage_ZongMenMember_HPP
#define UE4SS_SDK_BP_NotifyMessage_ZongMenMember_HPP

class UBP_NotifyMessage_ZongMenMember_C : public UFNGameNotifyMessage_ZongMen
{

    FString GetModuleName();
}; // Size: 0x78

#endif
