#ifndef UE4SS_SDK_BP_PlainHex_HPP
#define UE4SS_SDK_BP_PlainHex_HPP

class UBP_PlainHex_C : public UAreaLandTypeDescBase
{
}; // Size: 0x88

#endif
