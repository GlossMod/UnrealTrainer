#ifndef UE4SS_SDK_BP_TreeHex_HPP
#define UE4SS_SDK_BP_TreeHex_HPP

class UBP_TreeHex_C : public UAreaLandTypeDescBase
{
}; // Size: 0x88

#endif
