#ifndef UE4SS_SDK_BP_LifeRecord_HealByPoi_HPP
#define UE4SS_SDK_BP_LifeRecord_HealByPoi_HPP

class UBP_LifeRecord_HealByPoi_C : public ULifeRecordEntityBase
{
    double OldValue;                                                                  // 0x0030 (size: 0x8)
    double NewValue;                                                                  // 0x0038 (size: 0x8)
    int32 CellID;                                                                     // 0x0040 (size: 0x4)
    FString Text;                                                                     // 0x0048 (size: 0x10)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x58

#endif
