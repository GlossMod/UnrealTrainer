#ifndef UE4SS_SDK_BP_ItemUse_Wine_Hotel_HPP
#define UE4SS_SDK_BP_ItemUse_Wine_Hotel_HPP

class UBP_ItemUse_Wine_Hotel_C : public UItemUseFunction
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0030 (size: 0x8)
    FEnttIndex Causer Entity;                                                         // 0x0038 (size: 0x8)
    int32 User ID;                                                                    // 0x0040 (size: 0x4)
    TArray<int32> BuffID;                                                             // 0x0048 (size: 0x10)
    TArray<double> Weight_None;                                                       // 0x0058 (size: 0x10)
    TArray<double> Weight_WeiXun;                                                     // 0x0068 (size: 0x10)
    TArray<double> Weight_XiaoZui;                                                    // 0x0078 (size: 0x10)
    TArray<double> Weight_Dazui;                                                      // 0x0088 (size: 0x10)
    int32 FindIndex;                                                                  // 0x0098 (size: 0x4)
    TArray<double> Weight_Final;                                                      // 0x00A0 (size: 0x10)
    double TotalWeight;                                                               // 0x00B0 (size: 0x8)
    double ProcessValue;                                                              // 0x00B8 (size: 0x8)
    double Random;                                                                    // 0x00C0 (size: 0x8)
    int32 TargetBuffIndex;                                                            // 0x00C8 (size: 0x4)
    TArray<FString> Message;                                                          // 0x00D0 (size: 0x10)
    int32 CreateArttributeCheack;                                                     // 0x00E0 (size: 0x4)
    int32 CreateArttributeBuff;                                                       // 0x00E4 (size: 0x4)
    int32 DuanPianTime;                                                               // 0x00E8 (size: 0x4)
    int32 CreateArttributeCheack_DuanPian;                                            // 0x00EC (size: 0x4)
    ESpecialProductSubtype Special Product Subtype;                                   // 0x00F0 (size: 0x1)
    TArray<FString> Dec List;                                                         // 0x00F8 (size: 0x10)
    FName Sound Name;                                                                 // 0x0108 (size: 0x8)

    void PlaySound(int32 UserID, const class UObject* WorldContextObject);
    void OnAction_9D44A896472E9999E4A6FA913CB1AED8(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnEnd_9D44A896472E9999E4A6FA913CB1AED8(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnStart_9D44A896472E9999E4A6FA913CB1AED8(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnAction_216BB1D6457AC109250B5C913C886940(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnEnd_216BB1D6457AC109250B5C913C886940(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnStart_216BB1D6457AC109250B5C913C886940(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void ItemSpecialUse(class UItemBase* Item, int32 UserID);
    void ExecuteUbergraph_BP_ItemUse_Wine_Hotel(int32 EntryPoint);
}; // Size: 0x110

#endif
