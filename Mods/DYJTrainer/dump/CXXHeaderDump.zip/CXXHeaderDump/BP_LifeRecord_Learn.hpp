#ifndef UE4SS_SDK_BP_LifeRecord_Learn_HPP
#define UE4SS_SDK_BP_LifeRecord_Learn_HPP

class UBP_LifeRecord_Learn_C : public ULifeRecordEntityBase
{
    int32 LingFaID;                                                                   // 0x0030 (size: 0x4)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x34

#endif
