#ifndef UE4SS_SDK_BP_NotifyMessage_Stone_HPP
#define UE4SS_SDK_BP_NotifyMessage_Stone_HPP

class UBP_NotifyMessage_Stone_C : public UFNGameNotifyMessage_UseItemGetItems
{

    FString GetModuleName();
}; // Size: 0x98

#endif
