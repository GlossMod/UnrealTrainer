#ifndef UE4SS_SDK_SpinePlugin_HPP
#define UE4SS_SDK_SpinePlugin_HPP

struct FSpineAnimationStateMixData
{
    FString From;                                                                     // 0x0000 (size: 0x10)
    FString To;                                                                       // 0x0010 (size: 0x10)
    float Mix;                                                                        // 0x0020 (size: 0x4)

}; // Size: 0x28

struct FSpineEvent
{
    FString Name;                                                                     // 0x0000 (size: 0x10)
    FString StringValue;                                                              // 0x0010 (size: 0x10)
    int32 IntValue;                                                                   // 0x0020 (size: 0x4)
    float FloatValue;                                                                 // 0x0024 (size: 0x4)
    float Time;                                                                       // 0x0028 (size: 0x4)

}; // Size: 0x30

class USpineAtlasAsset : public UObject
{
    TArray<class UTexture2D*> atlasPages;                                             // 0x0028 (size: 0x10)
    FString RawData;                                                                  // 0x0040 (size: 0x10)
    FName atlasFileName;                                                              // 0x0050 (size: 0x8)

}; // Size: 0x58

class USpineBoneDriverComponent : public USceneComponent
{
    class AActor* Target;                                                             // 0x02A0 (size: 0x8)
    FString BoneName;                                                                 // 0x02A8 (size: 0x10)
    bool UseComponentTransform;                                                       // 0x02B8 (size: 0x1)
    bool UsePosition;                                                                 // 0x02B9 (size: 0x1)
    bool UseRotation;                                                                 // 0x02BA (size: 0x1)
    bool UseScale;                                                                    // 0x02BB (size: 0x1)

    void BeforeUpdateWorldTransform(class USpineSkeletonComponent* Skeleton);
}; // Size: 0x2D0

class USpineBoneFollowerComponent : public USceneComponent
{
    class AActor* Target;                                                             // 0x02A0 (size: 0x8)
    FString BoneName;                                                                 // 0x02A8 (size: 0x10)
    bool UseComponentTransform;                                                       // 0x02B8 (size: 0x1)
    bool UsePosition;                                                                 // 0x02B9 (size: 0x1)
    bool UseRotation;                                                                 // 0x02BA (size: 0x1)
    bool UseScale;                                                                    // 0x02BB (size: 0x1)

}; // Size: 0x2C0

class USpineSkeletonAnimationComponent : public USpineSkeletonComponent
{
    FSpineSkeletonAnimationComponentAnimationStart animationStart;                    // 0x00F8 (size: 0x10)
    void SpineAnimationStartDelegate(class UTrackEntry* entry);
    FSpineSkeletonAnimationComponentAnimationInterrupt AnimationInterrupt;            // 0x0108 (size: 0x10)
    void SpineAnimationInterruptDelegate(class UTrackEntry* entry);
    FSpineSkeletonAnimationComponentAnimationEvent AnimationEvent;                    // 0x0118 (size: 0x10)
    void SpineAnimationEventDelegate(class UTrackEntry* entry, FSpineEvent evt);
    FSpineSkeletonAnimationComponentAnimationComplete AnimationComplete;              // 0x0128 (size: 0x10)
    void SpineAnimationCompleteDelegate(class UTrackEntry* entry);
    FSpineSkeletonAnimationComponentAnimationEnd animationEnd;                        // 0x0138 (size: 0x10)
    void SpineAnimationEndDelegate(class UTrackEntry* entry);
    FSpineSkeletonAnimationComponentAnimationDispose AnimationDispose;                // 0x0148 (size: 0x10)
    void SpineAnimationDisposeDelegate(class UTrackEntry* entry);
    FString PreviewAnimation;                                                         // 0x0158 (size: 0x10)
    FString PreviewSkin;                                                              // 0x0168 (size: 0x10)
    TSet<UTrackEntry*> trackEntries;                                                  // 0x0180 (size: 0x50)
    bool bAutoPlaying;                                                                // 0x01D0 (size: 0x1)

    void SetTimeScale(float TimeScale);
    void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates);
    class UTrackEntry* SetEmptyAnimation(int32 TrackIndex, float mixDuration);
    void SetAutoPlay(bool bInAutoPlays);
    class UTrackEntry* SetAnimation(int32 TrackIndex, FString AnimationName, bool Loop);
    float GetTimeScale();
    class UTrackEntry* GetCurrent(int32 TrackIndex);
    void ClearTracks();
    void ClearTrack(int32 TrackIndex);
    class UTrackEntry* AddEmptyAnimation(int32 TrackIndex, float mixDuration, float Delay);
    class UTrackEntry* AddAnimation(int32 TrackIndex, FString AnimationName, bool Loop, float Delay);
}; // Size: 0x1F8

class USpineSkeletonComponent : public UActorComponent
{
    class USpineAtlasAsset* Atlas;                                                    // 0x00A0 (size: 0x8)
    class USpineSkeletonDataAsset* SkeletonData;                                      // 0x00A8 (size: 0x8)
    FSpineSkeletonComponentBeforeUpdateWorldTransform BeforeUpdateWorldTransform;     // 0x00B0 (size: 0x10)
    void SpineBeforeUpdateWorldTransformDelegate(class USpineSkeletonComponent* Skeleton);
    FSpineSkeletonComponentAfterUpdateWorldTransform AfterUpdateWorldTransform;       // 0x00C0 (size: 0x10)
    void SpineAfterUpdateWorldTransformDelegate(class USpineSkeletonComponent* Skeleton);

    void UpdateWorldTransform();
    void SetToSetupPose();
    void SetSlotsToSetupPose();
    void SetSlotColor(const FString SlotName, const FColor Color);
    bool SetSkins(TArray<FString>& SkinNames);
    bool SetSkin(const FString SkinName);
    void SetScaleY(float ScaleY);
    void SetScaleX(float ScaleX);
    void SetBoneWorldPosition(FString BoneName, const FVector& Position);
    void SetBonesToSetupPose();
    bool SetAttachment(const FString SlotName, const FString attachmentName);
    bool HasSlot(const FString SlotName);
    bool HasSkin(const FString SkinName);
    bool HasBone(const FString BoneName);
    bool HasAnimation(FString AnimationName);
    void GetSlots(TArray<FString>& Slots);
    void GetSkins(TArray<FString>& Skins);
    float GetScaleY();
    float GetScaleX();
    FTransform GetBoneWorldTransform(FString BoneName);
    void GetBones(TArray<FString>& Bones);
    void GetAnimations(TArray<FString>& Animations);
    float getAnimationDuration(FString AnimationName);
}; // Size: 0xF8

class USpineSkeletonDataAsset : public UObject
{
    float DefaultMix;                                                                 // 0x0028 (size: 0x4)
    TArray<FSpineAnimationStateMixData> MixData;                                      // 0x0030 (size: 0x10)
    TArray<FString> Bones;                                                            // 0x0040 (size: 0x10)
    TArray<FString> Slots;                                                            // 0x0050 (size: 0x10)
    TArray<FString> Skins;                                                            // 0x0060 (size: 0x10)
    TArray<FString> Animations;                                                       // 0x0070 (size: 0x10)
    TArray<FString> Events;                                                           // 0x0080 (size: 0x10)
    TArray<uint8> RawData;                                                            // 0x0090 (size: 0x10)
    FName skeletonDataFileName;                                                       // 0x00A0 (size: 0x8)

}; // Size: 0xF8

class USpineSkeletonRendererComponent : public UProceduralMeshComponent
{
    class UMaterialInterface* NormalBlendMaterial;                                    // 0x05F0 (size: 0x8)
    class UMaterialInterface* AdditiveBlendMaterial;                                  // 0x05F8 (size: 0x8)
    class UMaterialInterface* MultiplyBlendMaterial;                                  // 0x0600 (size: 0x8)
    class UMaterialInterface* ScreenBlendMaterial;                                    // 0x0608 (size: 0x8)
    TArray<class UMaterialInstanceDynamic*> atlasNormalBlendMaterials;                // 0x0610 (size: 0x10)
    TArray<class UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials;              // 0x0620 (size: 0x10)
    TArray<class UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials;              // 0x0630 (size: 0x10)
    TArray<class UMaterialInstanceDynamic*> atlasScreenBlendMaterials;                // 0x0640 (size: 0x10)
    float DepthOffset;                                                                // 0x0650 (size: 0x4)
    FName TextureParameterName;                                                       // 0x0654 (size: 0x8)
    FLinearColor Color;                                                               // 0x065C (size: 0x10)
    bool bCreateCollision;                                                            // 0x066C (size: 0x1)
    TArray<FVector> Vertices;                                                         // 0x0860 (size: 0x10)
    TArray<int32> Indices;                                                            // 0x0870 (size: 0x10)
    TArray<FVector> Normals;                                                          // 0x0880 (size: 0x10)
    TArray<FVector2D> UVs;                                                            // 0x0890 (size: 0x10)
    TArray<FColor> Colors;                                                            // 0x08A0 (size: 0x10)

}; // Size: 0x8B0

class USpineWidget : public UWidget
{
    FString InitialSkin;                                                              // 0x0150 (size: 0x10)
    class USpineAtlasAsset* Atlas;                                                    // 0x0160 (size: 0x8)
    class USpineSkeletonDataAsset* SkeletonData;                                      // 0x0168 (size: 0x8)
    class UMaterialInterface* NormalBlendMaterial;                                    // 0x0170 (size: 0x8)
    class UMaterialInterface* AdditiveBlendMaterial;                                  // 0x0178 (size: 0x8)
    class UMaterialInterface* MultiplyBlendMaterial;                                  // 0x0180 (size: 0x8)
    class UMaterialInterface* ScreenBlendMaterial;                                    // 0x0188 (size: 0x8)
    FName TextureParameterName;                                                       // 0x0190 (size: 0x8)
    float DepthOffset;                                                                // 0x0198 (size: 0x4)
    FLinearColor Color;                                                               // 0x019C (size: 0x10)
    FSlateBrush Brush;                                                                // 0x01B0 (size: 0xD0)
    FSpineWidgetBeforeUpdateWorldTransform BeforeUpdateWorldTransform;                // 0x0280 (size: 0x10)
    void SpineWidgetBeforeUpdateWorldTransformDelegate(class USpineWidget* Skeleton);
    FSpineWidgetAfterUpdateWorldTransform AfterUpdateWorldTransform;                  // 0x0290 (size: 0x10)
    void SpineWidgetAfterUpdateWorldTransformDelegate(class USpineWidget* Skeleton);
    FSpineWidgetAnimationStart animationStart;                                        // 0x02A0 (size: 0x10)
    void SpineAnimationStartDelegate(class UTrackEntry* entry);
    FSpineWidgetAnimationInterrupt AnimationInterrupt;                                // 0x02B0 (size: 0x10)
    void SpineAnimationInterruptDelegate(class UTrackEntry* entry);
    FSpineWidgetAnimationEvent AnimationEvent;                                        // 0x02C0 (size: 0x10)
    void SpineAnimationEventDelegate(class UTrackEntry* entry, FSpineEvent evt);
    FSpineWidgetAnimationComplete AnimationComplete;                                  // 0x02D0 (size: 0x10)
    void SpineAnimationCompleteDelegate(class UTrackEntry* entry);
    FSpineWidgetAnimationEnd animationEnd;                                            // 0x02E0 (size: 0x10)
    void SpineAnimationEndDelegate(class UTrackEntry* entry);
    FSpineWidgetAnimationDispose AnimationDispose;                                    // 0x02F0 (size: 0x10)
    void SpineAnimationDisposeDelegate(class UTrackEntry* entry);
    TArray<class UMaterialInstanceDynamic*> atlasNormalBlendMaterials;                // 0x0340 (size: 0x10)
    TArray<class UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials;              // 0x03A0 (size: 0x10)
    TArray<class UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials;              // 0x0400 (size: 0x10)
    TArray<class UMaterialInstanceDynamic*> atlasScreenBlendMaterials;                // 0x0460 (size: 0x10)
    TSet<UTrackEntry*> trackEntries;                                                  // 0x06B0 (size: 0x50)
    bool bAutoPlaying;                                                                // 0x0700 (size: 0x1)

    void UpdateWorldTransform();
    void Tick(float DeltaTime, bool CallDelegates);
    void SetToSetupPose();
    void SetTimeScale(float TimeScale);
    void SetSlotsToSetupPose();
    void SetSlotColor(const FString SlotName, const FLinearColor SlotColor);
    bool SetSkins(TArray<FString>& SkinNames);
    bool SetSkin(const FString SkinName);
    void SetScaleY(float ScaleY);
    void SetScaleX(float ScaleX);
    void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates);
    class UTrackEntry* SetEmptyAnimation(int32 TrackIndex, float mixDuration);
    void SetBonesToSetupPose();
    void SetAutoPlay(bool bInAutoPlays);
    bool SetAttachment(const FString SlotName, const FString attachmentName);
    class UTrackEntry* SetAnimation(int32 TrackIndex, FString AnimationName, bool Loop);
    bool HasSlot(const FString SlotName);
    bool HasSkin(const FString SkinName);
    bool HasBone(const FString BoneName);
    bool HasAnimation(FString AnimationName);
    float GetTimeScale();
    void GetSlots(TArray<FString>& Slots);
    void GetSkins(TArray<FString>& Skins);
    float GetScaleY();
    float GetScaleX();
    class UTrackEntry* GetCurrent(int32 TrackIndex);
    FTransform GetBoneTransform(FString BoneName);
    void GetBones(TArray<FString>& Bones);
    void GetAnimations(TArray<FString>& Animations);
    float getAnimationDuration(FString AnimationName);
    void ClearTracks();
    void ClearTrack(int32 TrackIndex);
    class UTrackEntry* AddEmptyAnimation(int32 TrackIndex, float mixDuration, float Delay);
    class UTrackEntry* AddAnimation(int32 TrackIndex, FString AnimationName, bool Loop, float Delay);
}; // Size: 0x710

class UTrackEntry : public UObject
{
    FTrackEntryAnimationStart animationStart;                                         // 0x0028 (size: 0x10)
    void SpineAnimationStartDelegate(class UTrackEntry* entry);
    FTrackEntryAnimationInterrupt AnimationInterrupt;                                 // 0x0038 (size: 0x10)
    void SpineAnimationInterruptDelegate(class UTrackEntry* entry);
    FTrackEntryAnimationEvent AnimationEvent;                                         // 0x0048 (size: 0x10)
    void SpineAnimationEventDelegate(class UTrackEntry* entry, FSpineEvent evt);
    FTrackEntryAnimationComplete AnimationComplete;                                   // 0x0058 (size: 0x10)
    void SpineAnimationCompleteDelegate(class UTrackEntry* entry);
    FTrackEntryAnimationEnd animationEnd;                                             // 0x0068 (size: 0x10)
    void SpineAnimationEndDelegate(class UTrackEntry* entry);
    FTrackEntryAnimationDispose AnimationDispose;                                     // 0x0078 (size: 0x10)
    void SpineAnimationDisposeDelegate(class UTrackEntry* entry);

    void SetTrackTime(float trackTime);
    void SetTrackEnd(float trackEnd);
    void SetTimeScale(float TimeScale);
    void SetMixTime(float mixTime);
    void SetMixDuration(float mixDuration);
    void SetLoop(bool Loop);
    void SetEventThreshold(float eventThreshold);
    void SetDrawOrderThreshold(float drawOrderThreshold);
    void SetDelay(float Delay);
    void SetAttachmentThreshold(float attachmentThreshold);
    void SetAnimationStart(float animationStart);
    void SetAnimationLast(float animationLast);
    void SetAnimationEnd(float animationEnd);
    void SetAlpha(float Alpha);
    bool isValidAnimation();
    float GetTrackTime();
    int32 GetTrackIndex();
    float GetTrackEnd();
    float GetTimeScale();
    float GetMixTime();
    float GetMixDuration();
    bool GetLoop();
    float GetEventThreshold();
    float GetDrawOrderThreshold();
    float GetDelay();
    float GetAttachmentThreshold();
    float GetAnimationStart();
    FString getAnimationName();
    float GetAnimationLast();
    float GetAnimationEnd();
    float getAnimationDuration();
    float GetAlpha();
}; // Size: 0x90

#endif
