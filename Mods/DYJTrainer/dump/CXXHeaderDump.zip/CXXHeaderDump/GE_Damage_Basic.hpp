#ifndef UE4SS_SDK_GE_Damage_Basic_HPP
#define UE4SS_SDK_GE_Damage_Basic_HPP

class UGE_Damage_Basic_C : public UBaseDamageGamePlayEffect
{
}; // Size: 0x868

#endif
