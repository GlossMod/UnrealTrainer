#ifndef UE4SS_SDK_BP_NotifyMessage_ZongMenJobChange_HPP
#define UE4SS_SDK_BP_NotifyMessage_ZongMenJobChange_HPP

class UBP_NotifyMessage_ZongMenJobChange_C : public UFNGameNotifyMessage_ZongMenWithNpcID
{

    FString GetModuleName();
}; // Size: 0x88

#endif
