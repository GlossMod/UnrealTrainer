#ifndef UE4SS_SDK_BP_PoiSceneUICpt_HPP
#define UE4SS_SDK_BP_PoiSceneUICpt_HPP

class UBP_PoiSceneUICpt_C : public UHexGridSceneUICpt
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x06B0 (size: 0x8)
    bool ShowPoiName;                                                                 // 0x06B8 (size: 0x1)

    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_PoiSceneUICpt(int32 EntryPoint);
}; // Size: 0x6B9

#endif
