#ifndef UE4SS_SDK_BP_PoiObject_Insight_HPP
#define UE4SS_SDK_BP_PoiObject_Insight_HPP

class UBP_PoiObject_Insight_C : public UPoibase
{
}; // Size: 0x170

#endif
