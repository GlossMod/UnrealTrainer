#ifndef UE4SS_SDK_BP_LifeRecord_GetTrauma_HPP
#define UE4SS_SDK_BP_LifeRecord_GetTrauma_HPP

class UBP_LifeRecord_GetTrauma_C : public UGetTraumaRecord
{

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x38

#endif
