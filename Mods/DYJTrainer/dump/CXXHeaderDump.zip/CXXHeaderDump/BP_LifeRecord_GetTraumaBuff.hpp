#ifndef UE4SS_SDK_BP_LifeRecord_GetTraumaBuff_HPP
#define UE4SS_SDK_BP_LifeRecord_GetTraumaBuff_HPP

class UBP_LifeRecord_GetTraumaBuff_C : public UGetTraumaBuffRecord
{

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x38

#endif
