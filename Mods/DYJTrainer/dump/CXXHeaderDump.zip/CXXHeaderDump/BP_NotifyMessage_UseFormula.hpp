#ifndef UE4SS_SDK_BP_NotifyMessage_UseFormula_HPP
#define UE4SS_SDK_BP_NotifyMessage_UseFormula_HPP

class UBP_NotifyMessage_UseFormula_C : public UFNGameNotifyMessage_UseItem
{

    FString GetModuleName();
}; // Size: 0x78

#endif
