#ifndef UE4SS_SDK_BP_Knowledge_OtherDeath_HPP
#define UE4SS_SDK_BP_Knowledge_OtherDeath_HPP

class UBP_Knowledge_OtherDeath_C : public UKnowledgeForOtherDeath
{

    FString GetModuleName();
}; // Size: 0x50

#endif
