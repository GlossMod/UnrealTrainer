#ifndef UE4SS_SDK_BP_NotifyMessage_QuestGetItems_HPP
#define UE4SS_SDK_BP_NotifyMessage_QuestGetItems_HPP

class UBP_NotifyMessage_QuestGetItems_C : public UFNGameNotifyMessage_QuestGetItems
{

    FString GetModuleName();
}; // Size: 0x98

#endif
