#ifndef UE4SS_SDK_BP_Knowledge_NPCGather_HPP
#define UE4SS_SDK_BP_Knowledge_NPCGather_HPP

class UBP_Knowledge_NPCGather_C : public UKnowledgeForGather
{

    FString GetModuleName();
}; // Size: 0x50

#endif
