#ifndef UE4SS_SDK_CS_FeijianShake_HPP
#define UE4SS_SDK_CS_FeijianShake_HPP

class UCS_FeijianShake_C : public UFNCameraShake
{
}; // Size: 0x220

#endif
