#ifndef UE4SS_SDK_BP_ItemUse_Luxurious_HPP
#define UE4SS_SDK_BP_ItemUse_Luxurious_HPP

class UBP_ItemUse_Luxurious_C : public UItemUseFunction
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0030 (size: 0x8)
    FEnttIndex Causer Entity;                                                         // 0x0038 (size: 0x8)
    int32 User ID;                                                                    // 0x0040 (size: 0x4)
    int32 BuffID;                                                                     // 0x0044 (size: 0x4)
    TArray<FString> Dec List;                                                         // 0x0048 (size: 0x10)
    ESpecialProductSubtype Special Product Subtype;                                   // 0x0058 (size: 0x1)
    FName Sound Name;                                                                 // 0x005C (size: 0x8)

    void PlaySound(int32 UserID, const class UObject* WorldContextObject);
    void OnAction_9D1C3B7247410586F9CED7A240E07D4F(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnEnd_9D1C3B7247410586F9CED7A240E07D4F(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnStart_9D1C3B7247410586F9CED7A240E07D4F(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void ItemSpecialUse(class UItemBase* Item, int32 UserID);
    void ExecuteUbergraph_BP_ItemUse_Luxurious(int32 EntryPoint);
}; // Size: 0x64

#endif
