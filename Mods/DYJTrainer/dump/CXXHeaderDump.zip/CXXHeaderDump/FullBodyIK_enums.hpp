enum class EFBIKBoneLimitType {
    Free = 0,
    Limit = 1,
    Locked = 2,
    EFBIKBoneLimitType_MAX = 3,
};

enum class EPoleVectorOption {
    Direction = 0,
    Location = 1,
    EPoleVectorOption_MAX = 2,
};

