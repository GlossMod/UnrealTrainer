#ifndef UE4SS_SDK_MinimapPlugin_HPP
#define UE4SS_SDK_MinimapPlugin_HPP

#include "MinimapPlugin_enums.hpp"

struct FMapBackgroundLevel
{
    class UTexture2D* BackgroundTexture;                                              // 0x0000 (size: 0x8)
    class UTextureRenderTarget2D* RenderTarget;                                       // 0x0008 (size: 0x8)
    class UTextureRenderTarget2D* Overlay;                                            // 0x0010 (size: 0x8)
    float LevelHeight;                                                                // 0x0018 (size: 0x4)
    FVector2D SamplingResolution;                                                     // 0x0020 (size: 0x10)

}; // Size: 0x30

class AMapAreaBase : public AActor
{
    class UBoxComponent* AreaBounds;                                                  // 0x0290 (size: 0x8)
    class UMapAreaPrimitiveComponent* AreaPrimitive;                                  // 0x0298 (size: 0x8)
    class UMapViewComponent* AreaMapView;                                             // 0x02A0 (size: 0x8)

    bool GetMapViewCornerUVs(class UMapViewComponent* MapView, TArray<FVector2D>& CornerUVs);
    class UMapViewComponent* GetMapView();
    float GetMapAspectRatio();
    int32 GetLevelAtHeight(const float WorldZ);
    class UBoxComponent* GetAreaBounds();
}; // Size: 0x2A8

class AMapBackground : public AMapAreaBase
{
    FMapBackgroundOnMapBackgroundTextureChanged OnMapBackgroundTextureChanged;        // 0x02A8 (size: 0x10)
    void MapBackgroundTextureChangedSignature(class AMapBackground* MapBackground);
    FMapBackgroundOnMapBackgroundMaterialChanged OnMapBackgroundMaterialChanged;      // 0x02B8 (size: 0x10)
    void MapBackgroundMaterialChangedSignature(class AMapBackground* MapBackground);
    FMapBackgroundOnMapBackgroundAppearanceChanged OnMapBackgroundAppearanceChanged;  // 0x02C8 (size: 0x10)
    void MapBackgroundAppearanceChangedSignature(class AMapBackground* MapBackground);
    FMapBackgroundOnMapBackgroundRendered OnMapBackgroundRendered;                    // 0x02D8 (size: 0x10)
    void MapBackgroundRenderedSignature(class AMapBackground* MapBackground, int32 Level, class UTextureRenderTarget2D* RenderTarget);
    FMapBackgroundOnMapBackgroundOverlayChanged OnMapBackgroundOverlayChanged;        // 0x02E8 (size: 0x10)
    void MapBackgroundOverlayChangedSignature(class AMapBackground* MapBackground, int32 Level, class UTextureRenderTarget2D* RenderTarget);
    TArray<FMapBackgroundLevel> BackgroundLevels;                                     // 0x02F8 (size: 0x10)
    class UMaterialInterface* BackgroundMaterial_UMG;                                 // 0x0308 (size: 0x8)
    class UMaterialInterface* BackgroundMaterial_Canvas;                              // 0x0310 (size: 0x8)
    bool bBackgroundVisible;                                                          // 0x0318 (size: 0x1)
    int32 BackgroundPriority;                                                         // 0x031C (size: 0x4)
    int32 BackgroundZOrder;                                                           // 0x0320 (size: 0x4)
    int32 DynamicRenderTargetSize;                                                    // 0x0324 (size: 0x4)
    TArray<class TSubclassOf<AActor>> HiddenActorClasses;                             // 0x0328 (size: 0x10)
    TArray<class AActor*> HiddenActors;                                               // 0x0338 (size: 0x10)
    bool bRenderNavigationMesh;                                                       // 0x0348 (size: 0x1)
    TMap<class UMapRendererComponent*, class UMaterialInstanceDynamic*> MaterialInstances; // 0x0350 (size: 0x50)
    TArray<class UBoxComponent*> LevelVisualizers;                                    // 0x03A0 (size: 0x10)
    class USceneCaptureComponent2D* CaptureComponent2D;                               // 0x03B8 (size: 0x8)
    class UNavMeshRenderingComponent* NavMeshRenderingComponent;                      // 0x03C0 (size: 0x8)

    void SetBackgroundZOrder(const int32 NewBackgroundZOrder);
    void SetBackgroundVisible(const bool bNewVisible);
    void SetBackgroundTexture(const int32 Level, class UTexture2D* NewBackgroundTexture);
    void SetBackgroundPriority(const int32 NewBackgroundPriority);
    void SetBackgroundOverlay(const int32 Level, class UTextureRenderTarget2D* NewBackgroundOverlay);
    void SetBackgroundMaterialForUMG(class UMaterialInterface* NewMaterial);
    void SetBackgroundMaterialForCanvas(class UMaterialInterface* NewMaterial);
    void RerenderBackground();
    bool IsMultiLevel();
    bool IsBackgroundVisible();
    int32 GetBackgroundZOrder();
    class UTexture* GetBackgroundTextureAtHeight(const float WorldZ);
    class UTexture* GetBackgroundTexture(const int32 Level);
    int32 GetBackgroundPriority();
    class UTextureRenderTarget2D* GetBackgroundOverlay(const int32 Level);
    class UMaterialInstanceDynamic* GetBackgroundMaterialInstanceForCanvas(class UMapRendererComponent* Renderer);
    class UMaterialInterface* GetBackgroundMaterialForUMG();
}; // Size: 0x3C8

class AMapFog : public AMapAreaBase
{
    FMapFogOnMapFogMaterialChanged OnMapFogMaterialChanged;                           // 0x02A8 (size: 0x10)
    void MapFogMaterialChangedSignature(class AMapFog* MapFog);
    int32 FogRenderTargetSize;                                                        // 0x02B8 (size: 0x4)
    class UMaterialInterface* FogMaterial_UMG;                                        // 0x02C0 (size: 0x8)
    class UMaterialInterface* FogMaterial_Canvas;                                     // 0x02C8 (size: 0x8)
    float MinimapOpacityHidden;                                                       // 0x02D0 (size: 0x4)
    float MinimapOpacityExplored;                                                     // 0x02D4 (size: 0x4)
    float MinimapOpacityRevealing;                                                    // 0x02D8 (size: 0x4)
    class UMaterialInterface* FogCombineMaterial;                                     // 0x02E0 (size: 0x8)
    float FogCacheLifetime;                                                           // 0x02E8 (size: 0x4)
    bool bEnableWorldFog;                                                             // 0x02EC (size: 0x1)
    class UMaterialInterface* FogPostProcessMaterial;                                 // 0x02F0 (size: 0x8)
    float WorldOpacityHidden;                                                         // 0x02F8 (size: 0x4)
    float WorldOpacityExplored;                                                       // 0x02FC (size: 0x4)
    float WorldOpacityRevealing;                                                      // 0x0300 (size: 0x4)
    class APostProcessVolume* PostProcessVolume;                                      // 0x0308 (size: 0x8)
    EFogPostProcessVolumeOption AutoLocatePostProcessVolume;                          // 0x0310 (size: 0x1)
    class UTextureRenderTarget2D* PermanentRevealRT_A;                                // 0x0318 (size: 0x8)
    class UTextureRenderTarget2D* PermanentRevealRT_B;                                // 0x0320 (size: 0x8)
    class UTextureRenderTarget2D* RevealRT_Staging;                                   // 0x0328 (size: 0x8)
    TMap<class UMapRendererComponent*, class UMaterialInstanceDynamic*> MaterialInstances; // 0x0338 (size: 0x50)
    class UMaterialInstanceDynamic* FogCombineMatInst;                                // 0x0388 (size: 0x8)
    class UMaterialInstanceDynamic* FogPostProcessMatInst;                            // 0x0390 (size: 0x8)
    TArray<class UMapRevealerComponent*> MapRevealers;                                // 0x03C8 (size: 0x10)

    void SetFogMaterialForUMG(class UMaterialInterface* NewMaterial);
    void SetFogMaterialForCanvas(class UMaterialInterface* NewMaterial);
    void OnMapRevealerUnregistered(class UMapRevealerComponent* MapRevealer);
    void OnMapRevealerRegistered(class UMapRevealerComponent* MapRevealer);
    float GetWorldToPixelRatio();
    class UTextureRenderTarget2D* GetSourceFogRenderTarget();
    class UMaterialInstanceDynamic* GetFogMaterialInstanceForCanvas(class UMapRendererComponent* Renderer);
    class UMaterialInterface* GetFogMaterialForUMG();
    bool GetFogAtLocation(const FVector& WorldLocation, const bool bRequireCurrentlyRevealing, float& RevealFactor);
    class UTextureRenderTarget2D* GetDestinationFogRenderTarget();
}; // Size: 0x3D8

class UMapAreaPrimitiveComponent : public UPrimitiveComponent
{
}; // Size: 0x550

class UMapFunctionLibrary : public UBlueprintFunctionLibrary
{

    class UMapTrackerComponent* GetMapTracker(const class UObject* WorldContextObject);
    class AMapBackground* GetFirstMapBackground(const class UObject* WorldContextObject);
    class UMapViewComponent* FindMapView(class UObject* WorldContextObject, const EMapViewSearchOption MapViewSearchOption);
    bool DetectIsInView(const FVector2D& uv, const FVector2D& OuterRadiusUV, const bool bIsCircular);
    bool ComputeViewFrustum(const class UObject* WorldContextObject, class UMapViewComponent* MapView, const bool bIsCircular, TArray<FVector2D>& CornerUVs, const float FloorDistance);
    FVector2D ClampIntoView(const FVector2D& uv, const float OuterRadiusUV, const bool bIsCircular);
    TArray<class UMapIconComponent*> BoxSelectInView(const FVector2D& StartUV, const FVector2D& EndUV, class UMapViewComponent* MapView, const bool bIsCircular);
}; // Size: 0x28

class UMapIconComponent : public UBillboardComponent
{
    FMapIconComponentOnIconAppearanceChanged OnIconAppearanceChanged;                 // 0x0560 (size: 0x10)
    void MapIconAppearanceChangedSignature(class UMapIconComponent* MapIcon);
    FMapIconComponentOnIconMaterialChanged OnIconMaterialChanged;                     // 0x0570 (size: 0x10)
    void MapIconMaterialChangedSignature(class UMapIconComponent* MapIcon);
    FMapIconComponentOnIconMaterialInstancesChanged OnIconMaterialInstancesChanged;   // 0x0580 (size: 0x10)
    void MapIconMaterialInstancesChangedSignature(class UMapIconComponent* MapIcon);
    FMapIconComponentOnIconEnteredView OnIconEnteredView;                             // 0x0590 (size: 0x10)
    void MapIconEnteredViewSignature(class UMapIconComponent* MapIcon, class UMapViewComponent* View);
    FMapIconComponentOnIconLeftView OnIconLeftView;                                   // 0x05A0 (size: 0x10)
    void MapIconLeftViewSignature(class UMapIconComponent* MapIcon, class UMapViewComponent* View);
    FMapIconComponentOnIconDestroyed OnIconDestroyed;                                 // 0x05B0 (size: 0x10)
    void MapIconDestroyedSignature(class UMapIconComponent* MapIcon);
    FMapIconComponentOnIconHoverStart OnIconHoverStart;                               // 0x05C0 (size: 0x10)
    void MapIconHoverStartSignature(class UMapIconComponent* MapIcon);
    FMapIconComponentOnIconHoverEnd OnIconHoverEnd;                                   // 0x05D0 (size: 0x10)
    void MapIconHoverEndSignature(class UMapIconComponent* MapIcon);
    FMapIconComponentOnIconClicked OnIconClicked;                                     // 0x05E0 (size: 0x10)
    void MapIconClickedSignature(class UMapIconComponent* MapIcon, bool bIsLeftMouse);
    FName IconCategory;                                                               // 0x05F0 (size: 0x8)
    class UTexture2D* IconTexture;                                                    // 0x05F8 (size: 0x8)
    class UMaterialInterface* IconMaterial_UMG;                                       // 0x0600 (size: 0x8)
    class UMaterialInterface* IconMaterial_Canvas;                                    // 0x0608 (size: 0x8)
    bool bIconVisible;                                                                // 0x0610 (size: 0x1)
    bool bIconRotates;                                                                // 0x0611 (size: 0x1)
    EIconSizeUnit IconSizeUnit;                                                       // 0x0612 (size: 0x1)
    float IconSize;                                                                   // 0x0614 (size: 0x4)
    FLinearColor IconDrawColor;                                                       // 0x0618 (size: 0x10)
    int32 IconZOrder;                                                                 // 0x0628 (size: 0x4)
    bool bObjectiveArrowEnabled;                                                      // 0x062C (size: 0x1)
    class UTexture2D* ObjectiveArrowTexture;                                          // 0x0630 (size: 0x8)
    class UMaterialInterface* ObjectiveArrowMaterial_UMG;                             // 0x0638 (size: 0x8)
    class UMaterialInterface* ObjectiveArrowMaterial_Canvas;                          // 0x0640 (size: 0x8)
    bool bObjectiveArrowRotates;                                                      // 0x0648 (size: 0x1)
    float ObjectiveArrowSize;                                                         // 0x064C (size: 0x4)
    bool bIconInteractable;                                                           // 0x0650 (size: 0x1)
    FName IconTooltipText;                                                            // 0x0654 (size: 0x8)
    EIconBackgroundInteraction IconBackgroundInteraction;                             // 0x065C (size: 0x1)
    EIconFogInteraction IconFogInteraction;                                           // 0x065D (size: 0x1)
    float IconFogRevealThreshold;                                                     // 0x0660 (size: 0x4)
    bool bHideOwnerInsideFog;                                                         // 0x0664 (size: 0x1)
    TMap<class UMapViewComponent*, class bool> IsRenderedPerView;                     // 0x0668 (size: 0x50)
    class UMaterialInterface* InitialIconMaterial_UMG;                                // 0x06B8 (size: 0x8)
    class UMaterialInterface* InitialIconMaterial_Canvas;                             // 0x06C0 (size: 0x8)
    TMap<class UUserWidget*, class UMaterialInstanceDynamic*> IconMaterialInstances_UMG; // 0x06C8 (size: 0x50)
    TMap<class UMapRendererComponent*, class UMaterialInstanceDynamic*> IconMaterialInstances_Canvas; // 0x0718 (size: 0x50)
    TMap<class UMapRendererComponent*, class UMaterialInstanceDynamic*> ObjectiveArrowMaterialInstances_Canvas; // 0x0768 (size: 0x50)

    void SetObjectiveArrowTexture(class UTexture2D* NewTexture);
    void SetObjectiveArrowSize(const float NewObjectiveArrowSize);
    void SetObjectiveArrowRotates(const bool bNewRotates);
    void SetObjectiveArrowEnabled(const bool bNewObjectiveArrowEnabled);
    void SetIconZOrder(const int32 NewZOrder);
    void SetIconVisible(const bool bNewVisible);
    void SetIconTooltipText(FName NewIconName);
    void SetIconTexture(class UTexture2D* NewIcon);
    void SetIconSize(const float NewIconSize, const EIconSizeUnit NewIconSizeUnit);
    void SetIconRotates(const bool bNewRotates);
    void SetIconMaterialForUMG(class UMaterialInterface* NewMaterial);
    void SetIconMaterialForCanvas(class UMaterialInterface* NewMaterial);
    void SetIconInteractable(const bool bNewInteractable);
    void SetIconFogRevealThreshold(const float NewFogRevealThreshold);
    void SetIconFogInteraction(const EIconFogInteraction NewFogInteraction);
    void SetIconDrawColor(const FLinearColor& NewDrawColor);
    void SetIconBackgroundInteraction(const EIconBackgroundInteraction NewBackgroundInteraction);
    void ResetIconMaterialForUMG();
    void ResetIconMaterialForCanvas();
    void RegisterMaterialInstanceFromUMG(class UUserWidget* IconWidget, class UMaterialInstanceDynamic* MatInst);
    void ReceiveHoverStart();
    void ReceiveHoverEnd();
    void ReceiveClicked(const bool bIsLeftMouseButton);
    bool MarkRenderedInView(class UMapViewComponent* View, const bool bNewIsRendered);
    bool IsRenderedInView(class UMapViewComponent* View);
    bool IsObjectiveArrowEnabled();
    bool IsIconVisible();
    bool IsIconInteractable();
    class UTexture2D* GetObjectiveArrowTexture();
    float GetObjectiveArrowSize();
    class UMaterialInterface* GetObjectiveArrowMaterialForUMG();
    class UMaterialInterface* GetObjectiveArrowMaterialForCanvas();
    int32 GetIconZOrder();
    FName GetIconTooltipText();
    class UTexture2D* GetIconTexture();
    EIconSizeUnit GetIconSizeUnit();
    float GetIconSize();
    void GetIconMaterialInstancesForUMG(TArray<class UMaterialInstanceDynamic*>& MaterialInstances);
    void GetIconMaterialInstancesForCanvas(TArray<class UMaterialInstanceDynamic*>& MaterialInstances);
    class UMaterialInterface* GetIconMaterialForUMG();
    class UMaterialInterface* GetIconMaterialForCanvas();
    float GetIconFogRevealThreshold();
    EIconFogInteraction GetIconFogInteraction();
    FLinearColor GetIconDrawColor();
    EIconBackgroundInteraction GetIconBackgroundInteraction();
    bool DoesObjectiveArrowRotate();
    bool DoesIconRotate();
}; // Size: 0x7C0

class UMapRendererComponent : public UActorComponent
{
    FMapRendererComponentOnMapClicked OnMapClicked;                                   // 0x00A0 (size: 0x10)
    void MapClickedSignature(FVector WorldLocation, bool bIsLeftMouseButton);
    EMapViewSearchOption AutoLocateMapView;                                           // 0x00B0 (size: 0x1)
    bool bIsCircular;                                                                 // 0x00B1 (size: 0x1)
    bool bIsRendered;                                                                 // 0x00B2 (size: 0x1)
    bool bDrawFrustum;                                                                // 0x00B3 (size: 0x1)
    float FrustumFloorDistance;                                                       // 0x00B4 (size: 0x4)
    FLinearColor BackgroundFillColor;                                                 // 0x00B8 (size: 0x10)
    TEnumAsByte<EHorizontalAlignment> HorizontalAlignment;                            // 0x00C8 (size: 0x1)
    TEnumAsByte<EVerticalAlignment> VerticalAlignment;                                // 0x00C9 (size: 0x1)
    FMargin Margin;                                                                   // 0x00CC (size: 0x10)
    FVector2D Size;                                                                   // 0x00E0 (size: 0x10)
    class UMaterialInterface* FillMaterial;                                           // 0x00F0 (size: 0x8)
    class UMaterialInstanceDynamic* FillMaterialInstance;                             // 0x00F8 (size: 0x8)
    class UMapTrackerComponent* MapTracker;                                           // 0x0100 (size: 0x8)
    class UMapViewComponent* MapView;                                                 // 0x0108 (size: 0x8)
    TSet<UMapIconComponent*> HoveringIcons;                                           // 0x0110 (size: 0x50)
    TArray<class UMapIconComponent*> BufferedHoverStartEvents;                        // 0x0160 (size: 0x10)
    TArray<class UMapIconComponent*> BufferedHoverEndEvents;                          // 0x0170 (size: 0x10)
    class UCanvas* LastCanvas;                                                        // 0x0180 (size: 0x8)

    void SetVerticalAlignment(TEnumAsByte<EVerticalAlignment> InVerticalAlignment);
    void SetSize(const int32 Width, const int32 Height);
    void SetMargin(const int32 Left, const int32 Top, const int32 Right, const int32 Bottom);
    void SetMapView(class UMapViewComponent* InMapView);
    void SetIsRendered(const bool bNewIsRendered);
    void SetIsCircular(const bool bNewIsCircular);
    void SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment);
    void SetFrustumFloorDistance(const float NewFrustumFloorDistance);
    void SetDrawFrustum(const bool bNewDrawFrustum);
    void SetBackgroundFillColor(const FLinearColor& NewBackgroundFillColor);
    void SetAutoLocateMapView(const EMapViewSearchOption InAutoLocateMapView);
    bool IsRendered();
    bool IsCircular();
    float GetFrustumFloorDistance();
    bool GetDrawFrustum();
    FLinearColor GetBackgroundFillColor();
}; // Size: 0x188

class UMapRevealerComponent : public UBoxComponent
{
    class UMaterialInterface* RevealMaterial;                                         // 0x0578 (size: 0x8)
    EMapFogRevealMode RevealMode;                                                     // 0x0580 (size: 0x1)
    float RevealDropOffDistance;                                                      // 0x0584 (size: 0x4)
    bool bTempEngineBugWorkaround;                                                    // 0x0588 (size: 0x1)
    class UMaterialInstanceDynamic* RevealMaterialInstance;                           // 0x0590 (size: 0x8)

    void SetRevealMode(const EMapFogRevealMode NewRevealMode);
    void SetRevealExtent(const float NewRevealExtentX, const float NewRevealExtentY);
    void SetRevealDropOffDistance(const float NewRevealDropOffDistance);
    EMapFogRevealMode GetRevealMode();
    void GetRevealExtent(float& RevealExtentX, float& RevealExtentY);
    float GetRevealDropOffDistance();
}; // Size: 0x5A0

class UMapTrackerComponent : public UActorComponent
{
    FMapTrackerComponentOnMapIconRegistered OnMapIconRegistered;                      // 0x00A0 (size: 0x10)
    void MapIconRegisteredSignature(class UMapIconComponent* MapIcon);
    FMapTrackerComponentOnMapIconUnregistered OnMapIconUnregistered;                  // 0x00B0 (size: 0x10)
    void MapIconUnregisteredSignature(class UMapIconComponent* MapIcon);
    FMapTrackerComponentOnMapBackgroundRegistered OnMapBackgroundRegistered;          // 0x00C0 (size: 0x10)
    void MapBackgroundRegisteredSignature(class AMapBackground* MapBackground);
    FMapTrackerComponentOnMapBackgroundUnregistered OnMapBackgroundUnregistered;      // 0x00D0 (size: 0x10)
    void MapBackgroundUnregisteredSignature(class AMapBackground* MapBackground);
    FMapTrackerComponentOnMapFogRegistered OnMapFogRegistered;                        // 0x00E0 (size: 0x10)
    void MapFogRegisteredSignature(class AMapFog* MapFog);
    FMapTrackerComponentOnMapFogUnregistered OnMapFogUnregistered;                    // 0x00F0 (size: 0x10)
    void MapFogRegisteredSignature(class AMapFog* MapFog);
    FMapTrackerComponentOnMapRevealerRegistered OnMapRevealerRegistered;              // 0x0100 (size: 0x10)
    void MapRevealerRegisteredSignature(class UMapRevealerComponent* MapRevealer);
    FMapTrackerComponentOnMapRevealerUnregistered OnMapRevealerUnregistered;          // 0x0110 (size: 0x10)
    void MapRevealerUnregisteredSignature(class UMapRevealerComponent* MapRevealer);
    TArray<class UMapIconComponent*> MapIcons;                                        // 0x0120 (size: 0x10)
    TArray<class AMapBackground*> MapBackgrounds;                                     // 0x0130 (size: 0x10)
    TArray<class AMapFog*> MapFogs;                                                   // 0x0140 (size: 0x10)
    TArray<class UMapRevealerComponent*> MapRevealers;                                // 0x0150 (size: 0x10)

    bool HasMapFog();
    TArray<class UMapRevealerComponent*> GetMapRevealers();
    TArray<class UMapIconComponent*> GetMapIcons();
    TArray<class AMapFog*> GetMapFogs();
    TArray<class AMapBackground*> GetMapBackgrounds();
    float GetFogRevealedFactor(const FVector& WorldLocation, const bool bRequireCurrentlyRevealing, bool& bIsInsideFogVolume);
}; // Size: 0x160

class UMapViewComponent : public UBoxComponent
{
    FMapViewComponentOnVisibleCategoriesChanged OnVisibleCategoriesChanged;           // 0x0578 (size: 0x10)
    void MapViewCategoriesChangedSignature(class UMapViewComponent* MapView);
    FMapViewComponentOnViewSizeChanged OnViewSizeChanged;                             // 0x0588 (size: 0x10)
    void MapViewSizeChangedSignature(class UMapViewComponent* MapView);
    FMapViewComponentOnViewDestroyed OnViewDestroyed;                                 // 0x0598 (size: 0x10)
    void MapViewDestroyedSignature(class UMapViewComponent* MapView);
    EMapViewRotationMode RotationMode;                                                // 0x05A8 (size: 0x1)
    FRotator FixedRotation;                                                           // 0x05B0 (size: 0x18)
    float InheritedYawOffset;                                                         // 0x05C8 (size: 0x4)
    bool bSupportZooming;                                                             // 0x05CC (size: 0x1)
    class USceneComponent* HeightProxy;                                               // 0x05D0 (size: 0x8)
    float BackgoundLevelCacheLifetime;                                                // 0x05D8 (size: 0x4)
    TSet<AMapBackground*> MapBackgrounds;                                             // 0x0720 (size: 0x50)
    TMap<AMapBackground*, int32> PositionOnMultiLevelBackgrounds;                     // 0x0770 (size: 0x50)

    bool ViewContains(const FVector& WorldPos, const float WorldRadius);
    void UnregisterMultiLevelMapBackground(class AMapBackground* MapBackground);
    void SetZoomScale(const float NewZoomScale);
    void SetViewExtent(const float NewViewExtentX, const float NewViewExtentY);
    void SetIconCategoryVisible(FName IconCategory, const bool bNewVisible);
    void RegisterMultiLevelMapBackground(class AMapBackground* MapBackground);
    bool IsSameBackgroundLevel(const class UMapIconComponent* MapIcon);
    bool IsIconCategoryVisible(FName IconCategory);
    float GetZoomScale();
    TArray<FVector> GetWorldCorners();
    void GetViewYaw(const float WorldYaw, float& Yaw);
    void GetViewExtent(float& ViewExtentX, float& ViewExtentY);
    bool GetViewCoordinates(const FVector& WorldPos, bool bForceRectangular, float& U, float& V);
    float GetViewAspectRatio();
    int32 GetActiveBackgroundPriority(bool& IsInsideAnyBackground);
    int32 GetActiveBackgroundLevel(const class AMapBackground* MapBackground);
    void DeprojectViewToWorld(const float U, const float V, FVector& WorldPos);
}; // Size: 0x810

#endif
