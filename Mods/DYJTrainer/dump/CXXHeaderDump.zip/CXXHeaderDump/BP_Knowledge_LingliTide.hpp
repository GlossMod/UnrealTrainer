#ifndef UE4SS_SDK_BP_Knowledge_LingliTide_HPP
#define UE4SS_SDK_BP_Knowledge_LingliTide_HPP

class UBP_Knowledge_LingliTide_C : public UKnowledgeForLingliTide
{

    FString GetModuleName();
}; // Size: 0x48

#endif
