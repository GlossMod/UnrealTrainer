#ifndef UE4SS_SDK_BP_LifeRecord_UseDanyao_HPP
#define UE4SS_SDK_BP_LifeRecord_UseDanyao_HPP

class UBP_LifeRecord_UseDanyao_C : public ULifeRecordEntityBase
{
    int32 DanYaoID;                                                                   // 0x0030 (size: 0x4)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x34

#endif
