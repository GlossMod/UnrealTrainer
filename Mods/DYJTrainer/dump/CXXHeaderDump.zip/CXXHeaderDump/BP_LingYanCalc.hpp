#ifndef UE4SS_SDK_BP_LingYanCalc_HPP
#define UE4SS_SDK_BP_LingYanCalc_HPP

class UBP_LingYanCalc_C : public UBigworldDynamicAttributeProcessBase
{
    FBigWorldAttributeName InsightAttribute;                                          // 0x0028 (size: 0x8)

    TArray<FBigWorldBaseAttributeParam> GetBigWorldBaseAttributeParams(class UGameInstance* GameInstance, const FEnttIndex& CauserEntity, int32 UserID);
}; // Size: 0x30

#endif
