#ifndef UE4SS_SDK_BP_LifeRecord_ZMChange_HPP
#define UE4SS_SDK_BP_LifeRecord_ZMChange_HPP

class UBP_LifeRecord_ZMChange_C : public UZMChangeRecord
{

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x40

#endif
