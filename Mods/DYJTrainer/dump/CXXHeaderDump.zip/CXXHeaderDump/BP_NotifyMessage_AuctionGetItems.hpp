#ifndef UE4SS_SDK_BP_NotifyMessage_AuctionGetItems_HPP
#define UE4SS_SDK_BP_NotifyMessage_AuctionGetItems_HPP

class UBP_NotifyMessage_AuctionGetItems_C : public UFNGameNotifyMessage_GetItems
{

    FString GetModuleName();
}; // Size: 0x90

#endif
