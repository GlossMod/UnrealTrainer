#ifndef UE4SS_SDK_BP_PoiObject_Guideboard_HPP
#define UE4SS_SDK_BP_PoiObject_Guideboard_HPP

class UBP_PoiObject_Guideboard_C : public UPoibase
{
    TArray<FBoardTargetPoint> BoardTargetPts;                                         // 0x0170 (size: 0x10)

    void GetBoardTargetPoints();
    void StartActionInternal(int32 Index);
    void Script_Trigger();
}; // Size: 0x180

#endif
