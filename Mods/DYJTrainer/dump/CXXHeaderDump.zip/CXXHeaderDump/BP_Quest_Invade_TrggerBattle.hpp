#ifndef UE4SS_SDK_BP_Quest_Invade_TrggerBattle_HPP
#define UE4SS_SDK_BP_Quest_Invade_TrggerBattle_HPP

class UBP_Quest_Invade_TrggerBattle_C : public UQuestEntityBase
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0120 (size: 0x8)
    FEnttIndex BattleEntity;                                                          // 0x0128 (size: 0x8)

    void OnAction_77AF8A0747C67FA44451E38C13FA9422(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnEnd_77AF8A0747C67FA44451E38C13FA9422(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnStart_77AF8A0747C67FA44451E38C13FA9422(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void Script_OnTake();
    void ExecuteUbergraph_BP_Quest_Invade_TrggerBattle(int32 EntryPoint);
}; // Size: 0x130

#endif
