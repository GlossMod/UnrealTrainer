enum class ESpudSaveSorting {
    None = 0,
    MostRecent = 1,
    SlotName = 2,
    Title = 3,
    ESpudSaveSorting_MAX = 4,
};

enum class ESpudSystemState {
    Disabled = 0,
    RunningIdle = 1,
    LoadingGame = 2,
    SavingGame = 3,
    ESpudSystemState_MAX = 4,
};

