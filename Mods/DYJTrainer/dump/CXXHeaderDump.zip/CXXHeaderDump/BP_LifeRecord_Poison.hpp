#ifndef UE4SS_SDK_BP_LifeRecord_Poison_HPP
#define UE4SS_SDK_BP_LifeRecord_Poison_HPP

class UBP_LifeRecord_Poison_C : public ULifeRecordEntityBase
{
    int32 ActionUserID;                                                               // 0x0030 (size: 0x4)
    int32 TargetUserID;                                                               // 0x0034 (size: 0x4)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x38

#endif
