#ifndef UE4SS_SDK_BP_QuestAction_OpenProductWnd_HPP
#define UE4SS_SDK_BP_QuestAction_OpenProductWnd_HPP

class UBP_QuestAction_OpenProductWnd_C : public UQuestActionEntityPrefabBase
{
    ESpecialProductSubtype SpecialProductSubtype;                                     // 0x0088 (size: 0x1)
    TArray<FString> DecList;                                                          // 0x0090 (size: 0x10)

    FString GetModuleName();
}; // Size: 0xA0

#endif
