#ifndef UE4SS_SDK_BP_NotifyMessage_JoinZongMen_HPP
#define UE4SS_SDK_BP_NotifyMessage_JoinZongMen_HPP

class UBP_NotifyMessage_JoinZongMen_C : public UFNGameNotifyMessage_ZongMenWithJob
{

    FString GetModuleName();
}; // Size: 0x80

#endif
