enum class EFogPostProcessVolumeOption {
    AutoLocate = 0,
    AutoLocateOrCreate = 1,
    Manual = 2,
    EFogPostProcessVolumeOption_MAX = 3,
};

enum class EIconBackgroundInteraction {
    AlwaysRender = 0,
    OnlyRenderInSameVolume = 1,
    OnlyRenderOnSameFloor = 2,
    OnlyRenderInPriorityVolume = 3,
    OnlyRenderOnPriorityFloor = 4,
    EIconBackgroundInteraction_MAX = 5,
};

enum class EIconFogInteraction {
    OnlyRenderWhenRevealing = 0,
    OnlyRenderWhenExplored = 1,
    AlwaysRenderUnderFog = 2,
    AlwaysRenderAboveFog = 3,
    EIconFogInteraction_MAX = 4,
};

enum class EIconSizeUnit {
    ScreenSpace = 0,
    WorldSpace = 1,
    EIconSizeUnit_MAX = 2,
};

enum class EMapFogRevealMode {
    Off = 0,
    Temporary = 1,
    Permanent = 2,
    EMapFogRevealMode_MAX = 3,
};

enum class EMapViewRotationMode {
    UseFixedRotation = 0,
    InheritYaw = 1,
    EMapViewRotationMode_MAX = 2,
};

enum class EMapViewSearchOption {
    Any = 0,
    OnPlayer = 1,
    OnMapBackground = 2,
    OnMapFog = 3,
    Disabled = 4,
    EMapViewSearchOption_MAX = 5,
};

