#ifndef UE4SS_SDK_BP_MainUIPolicy_HPP
#define UE4SS_SDK_BP_MainUIPolicy_HPP

class UBP_MainUIPolicy_C : public UGameUIPolicy
{
}; // Size: 0x70

#endif
