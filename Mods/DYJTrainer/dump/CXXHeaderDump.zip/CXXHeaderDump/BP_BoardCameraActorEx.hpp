#ifndef UE4SS_SDK_BP_BoardCameraActorEx_HPP
#define UE4SS_SDK_BP_BoardCameraActorEx_HPP

class ABP_BoardCameraActorEx_C : public AActor
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0290 (size: 0x8)
    class UCameraComponent* Camera;                                                   // 0x0298 (size: 0x8)
    class USpringArmComponent* SpringArm;                                             // 0x02A0 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x02A8 (size: 0x8)
    FVector EndLocation;                                                              // 0x02B0 (size: 0x18)
    FVector StartLocation;                                                            // 0x02C8 (size: 0x18)
    double Time;                                                                      // 0x02E0 (size: 0x8)
    double MaxTime;                                                                   // 0x02E8 (size: 0x8)
    bool bEnd;                                                                        // 0x02F0 (size: 0x1)
    int32 TargetIndex;                                                                // 0x02F4 (size: 0x4)
    int32 Range;                                                                      // 0x02F8 (size: 0x4)
    float StopDuration;                                                               // 0x02FC (size: 0x4)
    float BackTime;                                                                   // 0x0300 (size: 0x4)
    int32 DisableInputHandle;                                                         // 0x0304 (size: 0x4)

    FString GetModuleName();
    void UIOprate();
    void ReceiveBeginPlay();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_BP_BoardCameraActorEx(int32 EntryPoint);
}; // Size: 0x308

#endif
