#ifndef UE4SS_SDK_BP_NotifyMessage_LifeYear_HPP
#define UE4SS_SDK_BP_NotifyMessage_LifeYear_HPP

class UBP_NotifyMessage_LifeYear_C : public UFNGameNotifyMessage_Life
{

    FString GetModuleName();
}; // Size: 0x78

#endif
