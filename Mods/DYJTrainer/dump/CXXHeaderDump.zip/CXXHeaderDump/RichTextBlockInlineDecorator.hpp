#ifndef UE4SS_SDK_RichTextBlockInlineDecorator_HPP
#define UE4SS_SDK_RichTextBlockInlineDecorator_HPP

class URichTextBlockInlineDecorator : public URichTextBlockDecorator
{
}; // Size: 0x28

#endif
