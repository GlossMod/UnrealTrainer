#ifndef UE4SS_SDK_BP_NotifyMessage_MoodAutoChange_HPP
#define UE4SS_SDK_BP_NotifyMessage_MoodAutoChange_HPP

class UBP_NotifyMessage_MoodAutoChange_C : public UGameMsgNotifyBase
{

    FString GetModuleName();
}; // Size: 0x70

#endif
