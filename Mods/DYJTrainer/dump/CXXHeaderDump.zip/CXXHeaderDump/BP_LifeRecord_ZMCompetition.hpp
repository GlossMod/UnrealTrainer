#ifndef UE4SS_SDK_BP_LifeRecord_ZMCompetition_HPP
#define UE4SS_SDK_BP_LifeRecord_ZMCompetition_HPP

class UBP_LifeRecord_ZMCompetition_C : public ULifeRecordEntityBase
{
    int32 NpcID;                                                                      // 0x0030 (size: 0x4)
    int32 Rank;                                                                       // 0x0034 (size: 0x4)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x38

#endif
