#ifndef UE4SS_SDK_BP_QuestAction_Dialogue_HPP
#define UE4SS_SDK_BP_QuestAction_Dialogue_HPP

class UBP_QuestAction_Dialogue_C : public UQuestActionEntityPrefabBase
{
    FQuestAction_PlayDialogue DialogueParam;                                          // 0x0088 (size: 0x18)
    TMap<int32, int32> DynamicNpcIDMap;                                               // 0x00A0 (size: 0x50)
    TMap<class FString, class FString> CustomReplaceMap;                              // 0x00F0 (size: 0x50)
    bool bEndConversaton;                                                             // 0x0140 (size: 0x1)
    bool bHeadConversation;                                                           // 0x0141 (size: 0x1)

    FString GetModuleName();
}; // Size: 0x142

#endif
