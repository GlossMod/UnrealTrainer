#ifndef UE4SS_SDK_SoundFields_HPP
#define UE4SS_SDK_SoundFields_HPP

class UAmbisonicsEncodingSettings : public USoundfieldEncodingSettingsBase
{
    int32 AmbisonicsOrder;                                                            // 0x0028 (size: 0x4)

}; // Size: 0x30

#endif
