#ifndef UE4SS_SDK_BP_NotifyMessage_LifeTurn_HPP
#define UE4SS_SDK_BP_NotifyMessage_LifeTurn_HPP

class UBP_NotifyMessage_LifeTurn_C : public UFNGameNotifyMessage_Life
{

    FString GetModuleName();
}; // Size: 0x78

#endif
