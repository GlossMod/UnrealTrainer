#ifndef UE4SS_SDK_BP_NotifyMessage_LearnProgress_HPP
#define UE4SS_SDK_BP_NotifyMessage_LearnProgress_HPP

class UBP_NotifyMessage_LearnProgress_C : public UFNGameNotifyMessage_LearnLingFa
{

    FString GetModuleName();
}; // Size: 0x78

#endif
