#ifndef UE4SS_SDK_CS_SmallShake_HPP
#define UE4SS_SDK_CS_SmallShake_HPP

class UCS_SmallShake_C : public UFNCameraShake
{
}; // Size: 0x220

#endif
