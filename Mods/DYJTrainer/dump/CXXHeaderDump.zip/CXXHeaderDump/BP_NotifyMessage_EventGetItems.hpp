#ifndef UE4SS_SDK_BP_NotifyMessage_EventGetItems_HPP
#define UE4SS_SDK_BP_NotifyMessage_EventGetItems_HPP

class UBP_NotifyMessage_EventGetItems_C : public UFNGameNotifyMessage_GetItems
{

    FString GetModuleName();
}; // Size: 0x90

#endif
