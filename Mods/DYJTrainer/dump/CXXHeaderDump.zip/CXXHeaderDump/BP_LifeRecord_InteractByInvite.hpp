#ifndef UE4SS_SDK_BP_LifeRecord_InteractByInvite_HPP
#define UE4SS_SDK_BP_LifeRecord_InteractByInvite_HPP

class UBP_LifeRecord_InteractByInvite_C : public UInteractRecord
{

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x38

#endif
