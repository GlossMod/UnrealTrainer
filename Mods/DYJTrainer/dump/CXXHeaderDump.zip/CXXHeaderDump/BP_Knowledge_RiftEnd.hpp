#ifndef UE4SS_SDK_BP_Knowledge_RiftEnd_HPP
#define UE4SS_SDK_BP_Knowledge_RiftEnd_HPP

class UBP_Knowledge_RiftEnd_C : public UKnowledgeForRiftEnd
{

    FString GetModuleName();
}; // Size: 0x50

#endif
