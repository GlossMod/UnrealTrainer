#ifndef UE4SS_SDK_BP_Moutain_Hex_HPP
#define UE4SS_SDK_BP_Moutain_Hex_HPP

class UBP_Moutain_Hex_C : public UAreaLandTypeDescBase
{
}; // Size: 0x88

#endif
