#ifndef UE4SS_SDK_BP_ItemUse_Sentiment_HPP
#define UE4SS_SDK_BP_ItemUse_Sentiment_HPP

class UBP_ItemUse_Sentiment_C : public UItemUseFunction
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x0030 (size: 0x8)
    FEnttIndex Causer Entity;                                                         // 0x0038 (size: 0x8)
    int32 User ID;                                                                    // 0x0040 (size: 0x4)
    TArray<int32> BuffID;                                                             // 0x0048 (size: 0x10)
    int32 FindIndex;                                                                  // 0x0058 (size: 0x4)
    TArray<double> Weight_Final;                                                      // 0x0060 (size: 0x10)
    double TotalWeight;                                                               // 0x0070 (size: 0x8)
    double ProcessValue;                                                              // 0x0078 (size: 0x8)
    double Random;                                                                    // 0x0080 (size: 0x8)
    int32 TargetBuffIndex;                                                            // 0x0088 (size: 0x4)
    TArray<FString> Message;                                                          // 0x0090 (size: 0x10)
    ESpecialProductSubtype Special Product Subtype;                                   // 0x00A0 (size: 0x1)
    TArray<FString> Dec List;                                                         // 0x00A8 (size: 0x10)
    FName Sound Name;                                                                 // 0x00B8 (size: 0x8)

    void PlaySound(int32 UserID, const class UObject* WorldContextObject);
    void OnAction_223D30524D298DB49582E183BD9BD6A9(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnEnd_223D30524D298DB49582E183BD9BD6A9(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void OnStart_223D30524D298DB49582E183BD9BD6A9(class UQuestActionEntityPrefabBase* QuestActionEntityPrefabBase);
    void ItemSpecialUse(class UItemBase* Item, int32 UserID);
    void ExecuteUbergraph_BP_ItemUse_Sentiment(int32 EntryPoint);
}; // Size: 0xC0

#endif
