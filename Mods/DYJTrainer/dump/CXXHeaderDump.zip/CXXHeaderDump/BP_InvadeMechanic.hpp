#ifndef UE4SS_SDK_BP_InvadeMechanic_HPP
#define UE4SS_SDK_BP_InvadeMechanic_HPP

class UBP_InvadeMechanic_C : public UInvadeMechanic
{
    FPointerToUberGraphFrame UberGraphFrame;                                          // 0x00D8 (size: 0x8)

    void Script_OpenBattleWnd(FEnttIndex BattleEntity);
    void ExecuteUbergraph_BP_InvadeMechanic(int32 EntryPoint);
}; // Size: 0xE0

#endif
