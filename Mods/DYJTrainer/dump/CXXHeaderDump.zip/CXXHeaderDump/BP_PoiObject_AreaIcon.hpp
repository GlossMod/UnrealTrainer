#ifndef UE4SS_SDK_BP_PoiObject_AreaIcon_HPP
#define UE4SS_SDK_BP_PoiObject_AreaIcon_HPP

class UBP_PoiObject_AreaIcon_C : public UPoibase
{
}; // Size: 0x170

#endif
