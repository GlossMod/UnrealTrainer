#ifndef UE4SS_SDK_BP_Knowledge_GatherGen_HPP
#define UE4SS_SDK_BP_Knowledge_GatherGen_HPP

class UBP_Knowledge_GatherGen_C : public UKnowledgeFoLingcaiGenerate
{

    FString GetModuleName();
}; // Size: 0x50

#endif
