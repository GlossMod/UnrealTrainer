#ifndef UE4SS_SDK_BP_Knowledge_Auction_HPP
#define UE4SS_SDK_BP_Knowledge_Auction_HPP

class UBP_Knowledge_Auction_C : public UKnowledgeBase
{

    FString GetModuleName();
}; // Size: 0x48

#endif
