#ifndef UE4SS_SDK_BP_Knowledge_POI_B3_HPP
#define UE4SS_SDK_BP_Knowledge_POI_B3_HPP

class UBP_Knowledge_POI_B3_C : public UKnowledgeBase
{
    FString FixedConfigKeyName;                                                       // 0x0048 (size: 0x10)
    FString Dec;                                                                      // 0x0058 (size: 0x10)
    bool IsMain;                                                                      // 0x0068 (size: 0x1)
    FSoftObjectPath PoiImage;                                                         // 0x0070 (size: 0x20)

}; // Size: 0x90

#endif
