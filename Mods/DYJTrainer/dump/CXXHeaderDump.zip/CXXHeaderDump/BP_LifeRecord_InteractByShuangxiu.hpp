#ifndef UE4SS_SDK_BP_LifeRecord_InteractByShuangxiu_HPP
#define UE4SS_SDK_BP_LifeRecord_InteractByShuangxiu_HPP

class UBP_LifeRecord_InteractByShuangxiu_C : public UInteractRecord
{
    double MaxValue;                                                                  // 0x0038 (size: 0x8)
    double AddValue;                                                                  // 0x0040 (size: 0x8)
    FString Text;                                                                     // 0x0048 (size: 0x10)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x58

#endif
