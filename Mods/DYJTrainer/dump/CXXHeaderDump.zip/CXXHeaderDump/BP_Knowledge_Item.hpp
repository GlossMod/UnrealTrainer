#ifndef UE4SS_SDK_BP_Knowledge_Item_HPP
#define UE4SS_SDK_BP_Knowledge_Item_HPP

class UBP_Knowledge_Item_C : public UKnowledgeByItemID
{

    FString GetModuleName();
}; // Size: 0x50

#endif
