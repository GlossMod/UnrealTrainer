#ifndef UE4SS_SDK_SignificanceManager_HPP
#define UE4SS_SDK_SignificanceManager_HPP

class USignificanceManager : public UObject
{
    FSoftClassPath SignificanceManagerClassName;                                      // 0x0120 (size: 0x20)

}; // Size: 0x140

#endif
