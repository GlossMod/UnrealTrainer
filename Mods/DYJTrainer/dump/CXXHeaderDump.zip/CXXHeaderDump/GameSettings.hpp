#ifndef UE4SS_SDK_GameSettings_HPP
#define UE4SS_SDK_GameSettings_HPP

struct FGameSettingClassExtensions
{
    TArray<TSoftClassPtr<UGameSettingDetailExtension>> Extensions;                    // 0x0000 (size: 0x10)

}; // Size: 0x10

struct FGameSettingFilterState
{
    bool bIncludeDisabled;                                                            // 0x0000 (size: 0x1)
    bool bIncludeHidden;                                                              // 0x0001 (size: 0x1)
    bool bIncludeResetable;                                                           // 0x0002 (size: 0x1)
    bool bIncludeNestedPages;                                                         // 0x0003 (size: 0x1)
    TArray<class UGameSetting*> SettingRootList;                                      // 0x0398 (size: 0x10)
    TArray<class UGameSetting*> SettingAllowList;                                     // 0x03A8 (size: 0x10)

}; // Size: 0x3B8

struct FGameSettingNameExtensions
{
    bool bIncludeClassDefaultExtensions;                                              // 0x0000 (size: 0x1)
    TArray<TSoftClassPtr<UGameSettingDetailExtension>> Extensions;                    // 0x0008 (size: 0x10)

}; // Size: 0x18

class IGameSettingActionInterface : public IInterface
{

    bool ExecuteActionForSetting(FGameplayTag ActionTag, class UGameSetting* InSetting);
}; // Size: 0x28

class UGameResponsivePanel : public UPanelWidget
{
    bool bCanStackVertically;                                                         // 0x0168 (size: 0x1)

    class UGameResponsivePanelSlot* AddChildToGameResponsivePanel(class UWidget* Content);
}; // Size: 0x180

class UGameResponsivePanelSlot : public UPanelSlot
{
}; // Size: 0x40

class UGameSetting : public UObject
{
    class ULocalPlayer* LocalPlayer;                                                  // 0x0070 (size: 0x8)
    class UGameSetting* SettingParent;                                                // 0x0078 (size: 0x8)
    class UGameSettingRegistry* OwningRegistry;                                       // 0x0080 (size: 0x8)

    FText GetWarningRichText();
    FGameplayTagContainer GetTags();
    FText GetDynamicDetails();
    ESlateVisibility GetDisplayNameVisibility();
    FText GetDisplayName();
    FName GetDevName();
    FText GetDescriptionRichText();
}; // Size: 0x168

class UGameSettingAction : public UGameSetting
{
}; // Size: 0x1B8

class UGameSettingCollection : public UGameSetting
{
    TArray<class UGameSetting*> Settings;                                             // 0x0168 (size: 0x10)

}; // Size: 0x178

class UGameSettingCollectionPage : public UGameSettingCollection
{
}; // Size: 0x1A8

class UGameSettingDetailExtension : public UUserWidget
{
    class UGameSetting* Setting;                                                      // 0x0278 (size: 0x8)

    void OnSettingValueChanged(class UGameSetting* InSetting);
    void OnSettingAssigned(class UGameSetting* InSetting);
}; // Size: 0x280

class UGameSettingDetailView : public UUserWidget
{
    class UGameSettingVisualData* VisualData;                                         // 0x0278 (size: 0x8)
    FUserWidgetPool ExtensionWidgetPool;                                              // 0x0280 (size: 0x88)
    class UGameSetting* CurrentSetting;                                               // 0x0308 (size: 0x8)
    class UCommonTextBlock* Text_SettingName;                                         // 0x0320 (size: 0x8)
    class UCommonRichTextBlock* RichText_Description;                                 // 0x0328 (size: 0x8)
    class UCommonRichTextBlock* RichText_DynamicDetails;                              // 0x0330 (size: 0x8)
    class UCommonRichTextBlock* RichText_WarningDetails;                              // 0x0338 (size: 0x8)
    class UCommonRichTextBlock* RichText_DisabledDetails;                             // 0x0340 (size: 0x8)
    class UVerticalBox* Box_DetailsExtension;                                         // 0x0348 (size: 0x8)

}; // Size: 0x350

class UGameSettingListEntryBase : public UCommonUserWidget
{
    class UGameSetting* Setting;                                                      // 0x02B0 (size: 0x8)
    class UUserWidget* Background;                                                    // 0x02D0 (size: 0x8)

    class UWidget* GetPrimaryGamepadFocusWidget();
}; // Size: 0x2D8

class UGameSettingListEntrySetting_Action : public UGameSettingListEntry_Setting
{
    class UGameSettingAction* ActionSetting;                                          // 0x02E0 (size: 0x8)
    class UCommonButtonBase* Button_Action;                                           // 0x02E8 (size: 0x8)

    void OnSettingAssigned(const FText& ActionText);
}; // Size: 0x2F0

class UGameSettingListEntrySetting_Discrete : public UGameSettingListEntry_Setting
{
    class UGameSettingValueDiscrete* DiscreteSetting;                                 // 0x02E0 (size: 0x8)
    class UPanelWidget* Panel_Value;                                                  // 0x02E8 (size: 0x8)
    class UGameSettingRotator* Rotator_SettingValue;                                  // 0x02F0 (size: 0x8)
    class UCommonButtonBase* Button_Decrease;                                         // 0x02F8 (size: 0x8)
    class UCommonButtonBase* Button_Increase;                                         // 0x0300 (size: 0x8)

}; // Size: 0x308

class UGameSettingListEntrySetting_Navigation : public UGameSettingListEntry_Setting
{
    class UGameSettingCollectionPage* CollectionSetting;                              // 0x02E0 (size: 0x8)
    class UCommonButtonBase* Button_Navigate;                                         // 0x02E8 (size: 0x8)

    void OnSettingAssigned(const FText& ActionText);
}; // Size: 0x2F0

class UGameSettingListEntrySetting_Scalar : public UGameSettingListEntry_Setting
{
    class UGameSettingValueScalar* ScalarSetting;                                     // 0x02E0 (size: 0x8)
    class UPanelWidget* Panel_Value;                                                  // 0x02E8 (size: 0x8)
    class UAnalogSlider* Slider_SettingValue;                                         // 0x02F0 (size: 0x8)
    class UCommonTextBlock* Text_SettingValue;                                        // 0x02F8 (size: 0x8)

    void OnValueChanged(float Value);
    void OnDefaultValueChanged(float DefaultValue);
    void HandleSliderValueChanged(float Value);
    void HandleSliderCaptureEnded();
}; // Size: 0x300

class UGameSettingListEntry_Setting : public UGameSettingListEntryBase
{
    class UCommonTextBlock* Text_SettingName;                                         // 0x02D8 (size: 0x8)

}; // Size: 0x2E0

class UGameSettingListView : public UListView
{
    class UGameSettingVisualData* VisualData;                                         // 0x0C20 (size: 0x8)

}; // Size: 0xC80

class UGameSettingPanel : public UCommonUserWidget
{
    class UGameSettingRegistry* Registry;                                             // 0x02B8 (size: 0x8)
    TArray<class UGameSetting*> VisibleSettings;                                      // 0x02C0 (size: 0x10)
    class UGameSetting* LastHoveredOrSelectedSetting;                                 // 0x02D0 (size: 0x8)
    FGameSettingFilterState FilterState;                                              // 0x02D8 (size: 0x3B8)
    TArray<FGameSettingFilterState> FilterNavigationStack;                            // 0x0690 (size: 0x10)
    class UGameSettingListView* ListView_Settings;                                    // 0x06B0 (size: 0x8)
    class UGameSettingDetailView* Details_Settings;                                   // 0x06B8 (size: 0x8)
    FGameSettingPanelBP_OnExecuteNamedAction BP_OnExecuteNamedAction;                 // 0x06C0 (size: 0x10)
    void OnExecuteNamedActionBP(class UGameSetting* Setting, FGameplayTag Action);

}; // Size: 0x6E0

class UGameSettingPressAnyKey : public UCommonActivatableWidget
{

    void Refresh(class UGameSetting* GameSetting);
}; // Size: 0x410

class UGameSettingRegistry : public UObject
{
    TArray<class UGameSetting*> TopLevelSettings;                                     // 0x0088 (size: 0x10)
    TArray<class UGameSetting*> RegisteredSettings;                                   // 0x0098 (size: 0x10)
    class ULocalPlayer* OwningLocalPlayer;                                            // 0x00A8 (size: 0x8)

}; // Size: 0xB0

class UGameSettingRotator : public UCommonRotator
{

    void BP_OnDefaultOptionSpecified(int32 DefaultOptionIndex);
}; // Size: 0x1550

class UGameSettingScreen : public UCommonActivatableWidget
{
    class UGameSettingPanel* Settings_Panel;                                          // 0x0428 (size: 0x8)
    class UGameSettingRegistry* Registry;                                             // 0x0430 (size: 0x8)

    void OnSettingsDirtyStateChanged(bool bSettingsDirty);
    void NavigateToSettings(const TArray<FName>& SettingDevNames);
    void NavigateToSetting(FName SettingDevName);
    bool HaveSettingsBeenChanged();
    class UGameSettingCollection* GetSettingCollection(FName SettingDevName, bool& HasAnySettings);
    void CancelChanges();
    bool AttemptToPopNavigation();
    void ApplyChanges();
}; // Size: 0x438

class UGameSettingValue : public UGameSetting
{
}; // Size: 0x168

class UGameSettingValueDiscrete : public UGameSettingValue
{

    TArray<FText> GetDiscreteOptions();
    int32 GetDiscreteOptionIndex();
    int32 GetDiscreteOptionDefaultIndex();
}; // Size: 0x168

class UGameSettingValueDiscreteDynamic : public UGameSettingValueDiscrete
{
}; // Size: 0x1D0

class UGameSettingValueDiscreteDynamic_Bool : public UGameSettingValueDiscreteDynamic
{
}; // Size: 0x1D0

class UGameSettingValueDiscreteDynamic_Color : public UGameSettingValueDiscreteDynamic
{
}; // Size: 0x1D0

class UGameSettingValueDiscreteDynamic_Enum : public UGameSettingValueDiscreteDynamic
{
}; // Size: 0x1D0

class UGameSettingValueDiscreteDynamic_Number : public UGameSettingValueDiscreteDynamic
{
}; // Size: 0x1D0

class UGameSettingValueDiscreteDynamic_Vector2D : public UGameSettingValueDiscreteDynamic
{
}; // Size: 0x1D0

class UGameSettingValueScalar : public UGameSettingValue
{
}; // Size: 0x168

class UGameSettingValueScalarDynamic : public UGameSettingValueScalar
{
}; // Size: 0x230

class UGameSettingVisualData : public UDataAsset
{
    TMap<class TSubclassOf<UGameSetting>, class TSubclassOf<UGameSettingListEntryBase>> EntryWidgetForClass; // 0x0030 (size: 0x50)
    TMap<class FName, class TSubclassOf<UGameSettingListEntryBase>> EntryWidgetForName; // 0x0080 (size: 0x50)
    TMap<class TSubclassOf<UGameSetting>, class FGameSettingClassExtensions> ExtensionsForClasses; // 0x00D0 (size: 0x50)
    TMap<class FName, class FGameSettingNameExtensions> ExtensionsForName;            // 0x0120 (size: 0x50)

}; // Size: 0x170

class UKeyAlreadyBoundWarning : public UGameSettingPressAnyKey
{
    class UTextBlock* WarningText;                                                    // 0x0410 (size: 0x8)
    class UTextBlock* CancelText;                                                     // 0x0418 (size: 0x8)

}; // Size: 0x420

#endif
