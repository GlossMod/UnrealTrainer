#ifndef UE4SS_SDK_BP_NotifyMessage_Relationship_HPP
#define UE4SS_SDK_BP_NotifyMessage_Relationship_HPP

class UBP_NotifyMessage_Relationship_C : public UFNGameNotifyMessage_Relationship
{

    FString GetModuleName();
}; // Size: 0x80

#endif
