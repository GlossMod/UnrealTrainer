#ifndef UE4SS_SDK_BP_NotifyMessage_LearnLingFa_HPP
#define UE4SS_SDK_BP_NotifyMessage_LearnLingFa_HPP

class UBP_NotifyMessage_LearnLingFa_C : public UFNGameNotifyMessage_LearnLingFa
{

    FString GetModuleName();
}; // Size: 0x78

#endif
