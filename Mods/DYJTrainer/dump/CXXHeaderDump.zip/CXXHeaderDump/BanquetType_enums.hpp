namespace BanquetType {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        BanquetType_MAX = 2,
    };
}

