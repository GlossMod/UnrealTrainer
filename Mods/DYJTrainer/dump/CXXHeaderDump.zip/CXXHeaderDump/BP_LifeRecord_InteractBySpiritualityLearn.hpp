#ifndef UE4SS_SDK_BP_LifeRecord_InteractBySpiritualityLearn_HPP
#define UE4SS_SDK_BP_LifeRecord_InteractBySpiritualityLearn_HPP

class UBP_LifeRecord_InteractBySpiritualityLearn_C : public UInteractRecord
{
    int32 LingFaID;                                                                   // 0x0038 (size: 0x4)

    FString GetModuleName();
    FString GetLifeRecordString(int32 UserID);
}; // Size: 0x3C

#endif
