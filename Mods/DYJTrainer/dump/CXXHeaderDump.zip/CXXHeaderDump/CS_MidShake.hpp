#ifndef UE4SS_SDK_CS_MidShake_HPP
#define UE4SS_SDK_CS_MidShake_HPP

class UCS_MidShake_C : public UFNCameraShake
{
}; // Size: 0x220

#endif
