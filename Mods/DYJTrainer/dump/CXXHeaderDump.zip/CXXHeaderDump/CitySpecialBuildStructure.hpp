#ifndef UE4SS_SDK_CitySpecialBuildStructure_HPP
#define UE4SS_SDK_CitySpecialBuildStructure_HPP

struct FCitySpecialBuildStructure
{
    int32 SpecialBuildID_20_39C8EF724819E1F398216BA32AC0435A;                         // 0x0000 (size: 0x4)
    int32 Price_22_A77F58284BDCE37150277584F0C0CC9A;                                  // 0x0004 (size: 0x4)
    TArray<int32> BigWorldBuffID_39_DBB8847E482520FFB435DC86E3A64681;                 // 0x0008 (size: 0x10)
    int32 Time_24_4C288CB64101C06DC299A99AF514A8DE;                                   // 0x0018 (size: 0x4)
    FName SpecialName_17_F16DB31743774638AC72AF992285E24E;                            // 0x001C (size: 0x8)
    FName ButtonName_28_4EC211AF47B4CD02093213A327689D5A;                             // 0x0024 (size: 0x8)
    FSoftObjectPath BGImage_31_7869D8034D500E18417EA59927417C82;                      // 0x0030 (size: 0x20)
    FSoftObjectPath ButtonImage_35_0DB38BA14C1216EB45076D83DB0541AB;                  // 0x0050 (size: 0x20)
    int32 DialogID_38_F627CD0C4C55B372636130B2A964C575;                               // 0x0070 (size: 0x4)

}; // Size: 0x74

#endif
