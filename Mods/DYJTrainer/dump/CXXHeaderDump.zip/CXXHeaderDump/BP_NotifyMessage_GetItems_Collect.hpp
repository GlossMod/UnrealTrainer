#ifndef UE4SS_SDK_BP_NotifyMessage_GetItems_Collect_HPP
#define UE4SS_SDK_BP_NotifyMessage_GetItems_Collect_HPP

class UBP_NotifyMessage_GetItems_Collect_C : public UFNGameNotifyMessage_CollectGetItems
{

    FString GetModuleName();
}; // Size: 0x98

#endif
