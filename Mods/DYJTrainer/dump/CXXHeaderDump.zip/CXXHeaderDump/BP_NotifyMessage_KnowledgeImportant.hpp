#ifndef UE4SS_SDK_BP_NotifyMessage_KnowledgeImportant_HPP
#define UE4SS_SDK_BP_NotifyMessage_KnowledgeImportant_HPP

class UBP_NotifyMessage_KnowledgeImportant_C : public UFNGameNotifyMessage_KnowledgeImportant
{

    FString GetModuleName();
}; // Size: 0x78

#endif
