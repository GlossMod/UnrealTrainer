#ifndef UE4SS_SDK_BP_Item_Creator_Mount_HPP
#define UE4SS_SDK_BP_Item_Creator_Mount_HPP

class UBP_Item_Creator_Mount_C : public UItemCreatorBase
{

    FString GetModuleName();
}; // Size: 0x30

#endif
